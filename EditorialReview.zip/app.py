import os
import json
import re
import base64
import concurrent.futures
from flask import Flask, request, jsonify, send_from_directory, render_template
import docx
from docx.document import Document
from docx.oxml.ns import qn
import requests
from werkzeug.utils import secure_filename

# --- PERFORMANCE SETTINGS ---
# Set to False to disable image search and speed up processing significantly
USE_VISION = False 

# How many batches to process in parallel (Higher = Faster, but consumes more RAM/VRAM)
MAX_WORKERS = 5 

# How many paragraphs to send to AI in one go (Higher = Fewer API calls)
BATCH_SIZE = 7


# --- Global App Settings ---
ollama_model_name = r"gemma3-12b-14:latest" 
OLLAMA_API_URL = "http://localhost:11434/api/generate"

app = Flask(__name__)
UPLOADS_DIR = "uploads"
GENERATED_DIR = "generated"
os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(GENERATED_DIR, exist_ok=True)

# --- 1. OLLAMA CLIENT (Vision Enabled) ---
def call_ollama_vision(prompt, images=None):
    """
    Sends Text + Images to Ollama.
    """
    payload = {
        "model": ollama_model_name,
        "prompt": prompt,
        "stream": False,
        "options": {
            "num_ctx": 8192,
            "temperature": 0.1, # Low temperature for strict editing
            "num_predict": 2048,
        }
    }
    if USE_VISION and images:
        payload["images"] = images

    try:
        response = requests.post(OLLAMA_API_URL, json=payload)
        response.raise_for_status()
        return response.json().get('response', '')
    except Exception as e:
        print(f"Error calling Ollama API: {e}")
        return "[]"

# --- 2. DOCX & IMAGE EXTRACTION HELPER ---
def get_image_from_run(run, parent_part):
    """Extracts base64 image from a run if present."""

    if not USE_VISION: return None # Skip immediately if disabled

    try:
        blip_matches = run._element.xpath('.//*[local-name()="blip"]')
        if not blip_matches: return None
        
        for blip in blip_matches:
            embed_attr = blip.get(qn('r:embed'))
            if not embed_attr: continue
            
            image_part = parent_part.related_parts.get(embed_attr)
            if image_part:
                return base64.b64encode(image_part.blob).decode('utf-8')
    except Exception as e:
        print(f"Image extraction warning: {e}")
    return None

def get_formatting_tags(paragraph):
    """
    Extracts indentation and numbering info to help AI detect formatting errors.
    """
    tags = []
    
    # 1. Indentation Check
    if paragraph.paragraph_format.left_indent:
        indent_val = paragraph.paragraph_format.left_indent.inches
        if indent_val and indent_val > 0.6: 
            tags.append(f"[INDENTATION: {indent_val:.1f} inches]")

    # 2. Manual Numbering Check (Regex)
    text = paragraph.text.strip()
    if re.match(r'^(\d+(\.\d+)*|[A-Z]|[a-z]|\([a-z0-9]+\))[\.\)]\s', text):
        tags.append("[NUMBERED_ITEM]")
    
    # 3. Automatic List Style Check (Word XML)
    if paragraph._p.pPr is not None and paragraph._p.pPr.numPr is not None:
        tags.append("[AUTO_LIST_ITEM]")

    return " ".join(tags)

def table_to_markdown(table):
    """Converts table to Markdown to expose empty cells."""
    md_rows = []
    try:
        headers = [cell.text.strip() for cell in table.rows[0].cells]
        md_rows.append("| " + " | ".join(headers) + " |")
        md_rows.append("| " + " | ".join(["---"] * len(headers)) + " |")
        for row in table.rows[1:]:
            row_cells = [cell.text.strip() if cell.text.strip() else "MISSING_DATA" for cell in row.cells]
            md_rows.append("| " + " | ".join(row_cells) + " |")
    except: return "[Complex Table]"
    return "\n".join(md_rows)

def iter_block_items(parent):
    if isinstance(parent, Document): parent_elm = parent.element.body
    else: parent_elm = parent._element
    for child in parent_elm.iterchildren():
        if child.tag.endswith('p'): yield docx.text.paragraph.Paragraph(child, parent)
        elif child.tag.endswith('tbl'): yield docx.table.Table(child, parent)

def analyze_doc_structure(file_path):
    doc = docx.Document(file_path)
    blocks = []
    
    blank_line_counter = 0

    for block in iter_block_items(doc):
        # A. Paragraphs
        if isinstance(block, docx.text.paragraph.Paragraph):
            text = block.text.strip()
            style = block.style.name.lower()
            
            # Check for Extra Spaces
            if not text:
                blank_line_counter += 1
                if blank_line_counter > 2:
                    blocks.append({
                        "type": "issue",
                        "original_text": "[BLANK SPACE]",
                        "corrected_text": "[DELETE]",
                        "issues_found": ["Formatting"],
                        "consolidated_reason": "Excessive vertical whitespace (3+ empty lines)."
                    })
                continue 
            else:
                blank_line_counter = 0

            # 1. Formatting Detection
            fmt_tags = get_formatting_tags(block)

            # Image Extraction
            images = []
            if USE_VISION:
                for run in block.runs:
                    img = get_image_from_run(run, doc.part)
                    if img: images.append(img)
            
            blocks.append({
                "type": "paragraph",
                "text": text,
                "style": style,
                "images": images,
                "fmt_tags": fmt_tags
            })

        # B. Tables
        elif isinstance(block, docx.table.Table):
            blocks.append({
                "type": "table",
                "text": table_to_markdown(block),
                "images": []
            })
            blank_line_counter = 0

    return blocks

# # --- 3. PARALLEL ANALYSIS LOGIC ---

# def process_single_batch(batch):
#     """Worker function for processing one batch of text."""
#     prompt_text = ""
#     batch_images = []
#     img_idx = 1
    
#     for item in batch:
#         # Build prompt
#         if item.get('images') and USE_VISION:
#             prompt_text += f"\n[IMAGE {img_idx}]\nSurrounding Text: {item['text']}\n"
#             batch_images.extend(item['images'])
#             img_idx += 1
#         elif item['type'] == 'table':
#             prompt_text += f"\n[TABLE START]\n{item['text']}\n[TABLE END]\n"
#         else:
#             prefix = f"[{item['style'].upper()}]"
#             if item.get('fmt_tags'): prefix += f" {item['fmt_tags']}"
#             prompt_text += f"{prefix}: {item['text']}\n"

#     if not prompt_text.strip(): return []

#     system_prompt = """You are a professional Technical Editor. Review the provided document segment.

# **STRICT EDITORIAL RULES:**
# 1. **Grammar & Style:** Correct grammar, punctuation, and awkward phrasing. Ensure correct SI unit naming (e.g. 'kg', 'kV'). Flag undefined acronyms.
# 2. **Structure:** Ensure Headings are logical (e.g., Heading 1 -> Heading 3 is wrong). Flag missing titles.
# 3. **Formatting:** Check [INDENTATION] and [NUMBERED_ITEM] for consistency/logic.
# 4. **Table Data:** If a cell contains 'MISSING_DATA' or '||', flag it.
# 5. **Captions:** If [IMAGE] or [TABLE], check for nearby captions.

# **FILTERING RULES:**
# - If a sentence is correct, DO NOT include it in the output.
# - Only output items that require a change.

# **OUTPUT FORMAT:**
# Return ONLY a valid JSON list. Escape backslashes.
# [
#   {
#     "original_text": "original text segment",
#     "corrected_text": "correction",
#     "issues_found": ["Grammar", "Formatting", "Structure"],
#     "consolidated_reason": "reason"
#   }
# ]
# If no errors, return [].
# """
#     full_prompt = f"<|start_header_id|>system<|end_header_id|>\n\n{system_prompt}<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n{prompt_text}<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n"
    
#     # Call AI
#     response_text = call_ollama_vision(full_prompt, batch_images)
    
#     # Parse Response
#     found_corrections = []
#     try:
#         clean_json = response_text.replace("```json", "").replace("```", "").strip()
#         found_corrections = json.loads(clean_json)
#     except json.JSONDecodeError:
#         try:
#             clean_json_fixed = clean_json.replace('\n', '\\n')
#             found_corrections = json.loads(clean_json_fixed)
#         except:
#             try:
#                 clean_json_fixed = re.sub(r'(?<!\\)\\(?!["\\/bfnrtu])', r'\\\\', clean_json)
#                 found_corrections = json.loads(clean_json_fixed)
#             except:
#                 pass # Fail silently for speed
                
#     return found_corrections

# def run_gemma_analysis(content_blocks):
#     all_corrections = []
    
#     # 1. Add Python-detected issues immediately (Fastest)
#     python_found_issues = [b for b in content_blocks if b.get("type") == "issue"]
#     all_corrections.extend(python_found_issues)
    
#     # 2. Prepare batches for LLM
#     llm_items = [b for b in content_blocks if b.get("type") != "issue"]
#     batches = [llm_items[i:i + BATCH_SIZE] for i in range(0, len(llm_items), BATCH_SIZE)]
    
#     print(f"Starting parallel analysis of {len(batches)} batches with {MAX_WORKERS} workers...")

#     # 3. Parallel Execution
#     with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
#         results = list(executor.map(process_single_batch, batches))
    
#     # 4. Aggregate Results
#     for res in results:
#         if res: all_corrections.extend(res)

#     # 5. FINAL SANITIZATION: Remove "No Change" entries
#     # Sometimes AI returns correction identical to original. We remove these.
#     filtered_corrections = []
#     for corr in all_corrections:
#         orig = corr.get("original_text", "").strip()
#         new = corr.get("corrected_text", "").strip()
        
#         # Logic: If corrected text is same as original, it's not an issue.
#         # Also remove empty entries.
#         if orig and new and orig != new:
#             filtered_corrections.append(corr)
    
#     return filtered_corrections


# --- 3. MAIN LOGIC ---
def run_gemma_analysis(content_blocks):
    all_corrections = []
    
    BATCH_SIZE = 5
    for i in range(0, len(content_blocks), BATCH_SIZE):
        batch = content_blocks[i:i+BATCH_SIZE]
        
        # 1. Add Python-detected issues
        python_found_issues = [b for b in batch if b.get("type") == "issue"]
        all_corrections.extend(python_found_issues)
        
        llm_batch = [b for b in batch if b.get("type") != "issue"]
        if not llm_batch: continue

        prompt_text = ""
        batch_images = []
        img_idx = 1
        
        for item in llm_batch:
            if item['images']:
                prompt_text += f"\n[IMAGE {img_idx}]\n"
                prompt_text += f"Surrounding Text: {item['text']}\n"
                batch_images.extend(item['images'])
                img_idx += 1
            elif item['type'] == 'table':
                prompt_text += f"\n[TABLE START]\n{item['text']}\n[TABLE END]\n"
            else:
                prefix = f"[{item['style'].upper()}]" 
                prompt_text += f"{prefix}: {item['text']}\n"

        if not prompt_text.strip(): continue

        print(f"Processing batch with {len(batch_images)} images...")

        system_prompt = """You are a professional Technical Editor. Review the provided document segment.

**STRICT EDITORIAL RULES:**
1. **Grammar & Technical Style:** - Correct grammar, punctuation, and awkward phrasing.
   - **SI Units:** Ensure correct SI unit naming and spacing (e.g., 'kg', 'kV', 'MVA').
   - **Acronyms:** Flag undefined acronyms on first use.
2. **Structure & Headings:** - **Hierarchy:** Ensure Headings are logical (e.g., Heading 1 should not be followed immediately by Heading 3).
   - **Missing Titles:** Flag sections that clearly require a header or title but lack one.
3. **Formatting & Layout:**
   - **Capitalization:** Check for inconsistent capitalization in titles (Title Case vs Sentence Case) and proper nouns.
   - **Indentation:** Check [INDENTATION]: Is it random or inconsistent with the text style?
   - **Numbering:** Check [NUMBERED_ITEM]: Is the sequence logical? (e.g. "1." followed by "3." or "A." followed by "C.").
4. **Visuals & Tables:**
   - **Captions:** If you see an [IMAGE X] or [TABLE], check if there is a caption immediately before or after it.
   - **Table Data:** If a cell contains 'MISSING_DATA' or '||', flag it.
   
**OUTPUT FORMAT:**
Return ONLY a valid JSON list. Escape all backslashes (e.g. use \\\\ for \\).
[
  {
    "original_text": "text",
    "corrected_text": "correction",
    "issues_found": ["Grammar", "Style", "Structure", "Formatting", "Caption", "Table Data"],
    "consolidated_reason": "reason"
  }
]
If no errors, return [].
"""
        full_prompt = f"<|start_header_id|>system<|end_header_id|>\n\n{system_prompt}<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n{prompt_text}<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n"
        
        response_text = call_ollama_vision(full_prompt, batch_images)

#--------------------------------------------OLD PROMPT-------------------------------------------------------------------
#         system_prompt = """You are a professional Technical Editor. Review the provided document segment.

# **STRICT EDITORIAL RULES:**
# 1. **Grammar & Flow:** Correct grammar, punctuation, and awkward phrasing. Also check for SI units naming (e.g kV, kg, MVA)
# 2. **Missing Captions:** If you see an [IMAGE X] or [TABLE], check if there is a caption immediately before or after it.
# 3. **Formatting:** Ensure Headings are logical.
# 4. **Table Data:** If a cell contains 'MISSING_DATA' or '||', flag it.
# 5. **Formatting:** - Check [INDENTATION]: Is it random or inconsistent with the text style?
#     - Check [NUMBERED_ITEM]: Is the sequence logical? (e.g. "1." followed by "3." or "A." followed by "C.").

# **OUTPUT FORMAT:**
# Return ONLY a valid JSON list. Escape all backslashes (e.g. use \\\\ for \\).
# [
#   {
#     "original_text": "text",
#     "corrected_text": "correction",
#     "issues_found": ["Grammar"],
#     "consolidated_reason": "reason"
#   }
# ]
# If no errors, return [].
# """
#         full_prompt = f"<|start_header_id|>system<|end_header_id|>\n\n{system_prompt}<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n{prompt_text}<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n"
        
#         response_text = call_ollama_vision(full_prompt, batch_images)
#----------------------------------------------------------------------------------------------------------------------------------------------        
        try:
            clean_json = response_text.replace("```json", "").replace("```", "").strip()
            corrections = json.loads(clean_json)
            all_corrections.extend(corrections)
            
        except json.JSONDecodeError:
            # 3. First Fallback: Fix Control Characters
            try:
                clean_json_fixed = clean_json.replace('\n', '\\n')
                corrections = json.loads(clean_json_fixed)
                all_corrections.extend(corrections)
                print(" -> Successfully repaired JSON (Control Characters)")
            except:
                # 4. Second Fallback: Fix Backslashes
                try:
                    clean_json_fixed = re.sub(r'(?<!\\)\\(?!["\\/bfnrtu])', r'\\\\', clean_json)
                    corrections = json.loads(clean_json_fixed)
                    all_corrections.extend(corrections)
                    print(" -> Successfully repaired JSON (Backslashes)")
                except:
                    print(f" -> Skipped batch due to malformed JSON from AI.")
        except Exception as e:
            print(f"General Error: {e}")

    return all_corrections

# --- 4. COMMENT INJECTION ---
def add_comments_to_docx(original_path, corrections):
    try:
        doc = docx.Document(original_path)
        commented_texts = set()

        for correction in corrections:
            original_text = correction.get("original_text", "").strip()
            
            # --- CASE A: BLANK SPACES  ---
            if original_text == "[BLANK SPACE]":
                empty_count = 0
                for paragraph in doc.paragraphs:
                    if not paragraph.text.strip():
                        empty_count += 1
                        if empty_count == 3: 
                            doc.add_comment(
                                text=f"Suggestion: {correction.get('corrected_text')}\nReason: {correction.get('consolidated_reason')}",
                                runs=paragraph.runs if paragraph.runs else paragraph.add_run(" "), # Ensure there is a run to attach to
                                author="AI Reviewer",
                                initials="AI"
                            )
                            break 
                    else:
                        empty_count = 0
                continue

            # --- CASE B: TABLE DATA ---
            is_table_issue = "MISSING_DATA" in original_text or "|" in original_text
            
            if is_table_issue:
                # 1. Clean the markdown to get keywords
                keywords = [k.strip() for k in original_text.split('|') if k.strip() and k.strip() != "MISSING_DATA"]
                
                # 2. Search all tables
                for table in doc.tables:
                    for row in table.rows:
                        row_text = " ".join([cell.text for cell in row.cells])
                        
                        if keywords and all(k in row_text for k in keywords):
                            if row_text in commented_texts: continue
                            
                            target_paragraph = row.cells[0].paragraphs[0] # Default to first cell
                            for cell in row.cells:
                                if not cell.text.strip():
                                    if cell.paragraphs:
                                        target_paragraph = cell.paragraphs[0]
                                        break
                            
                            doc.add_comment(
                                text=f"Suggestion: {correction.get('corrected_text')}\nReason: {correction.get('consolidated_reason')}",
                                runs=target_paragraph.runs if target_paragraph.runs else target_paragraph.add_run(" "),
                                author="AI Reviewer",
                                initials="AI"
                            )
                            commented_texts.add(row_text)
                            break 
                continue

            # --- CASE C: STANDARD TEXT  ---
            if original_text in commented_texts: continue

            clean_text = re.sub(r'^(\[.*?\]\s*)+:?\s*', '', original_text)
            if not clean_text: clean_text = original_text

            # 1. Search Body Paragraphs
            found = False
            for paragraph in doc.paragraphs:
                if clean_text in paragraph.text:
                    doc.add_comment(
                        text=f"Suggestion: {correction.get('corrected_text')}\nReason: {correction.get('consolidated_reason')}",
                        runs=paragraph.runs,
                        author="AI Reviewer",
                        initials="AI"
                    )
                    commented_texts.add(original_text)
                    found = True
                    break 
            
            if found: continue

            # 2. Search Table Paragraphs
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        for paragraph in cell.paragraphs:
                            if original_text in paragraph.text:
                                doc.add_comment(
                                    text=f"Suggestion: {correction.get('corrected_text')}\nReason: {correction.get('consolidated_reason')}",
                                    runs=paragraph.runs,
                                    author="AI Reviewer",
                                    initials="AI"
                                )
                                commented_texts.add(original_text)
                                found = True
                                break
                        if found: break
                    if found: break
        
        new_filename = f"Reviewed_{os.path.basename(original_path)}"
        save_path = os.path.join(GENERATED_DIR, new_filename)
        doc.save(save_path)
        return new_filename

    except Exception as e:
        print(f"Error adding comments to DOCX: {e}")
        return None

# --- 5. ROUTES ---
@app.route('/')
def index():
    return render_template("ui_template.html")

@app.route('/review_document', methods=['POST'])
def review_document():
    if 'document_file' not in request.files: 
        return jsonify({"error": "No file uploaded"}), 400
    
    file = request.files['document_file']
    
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400
        
    filename = secure_filename(file.filename)
    
    if not filename.lower().endswith('.docx'):
        return jsonify({
            "error": "Format not supported. Please upload a .docx file. (PDFs do not contain the structural data needed for this specific analysis)"
        }), 400

    file_path = os.path.join(UPLOADS_DIR, filename)
    file.save(file_path)

    try:
        # 3. Analyze Structure & Images
        content_blocks = analyze_doc_structure(file_path)
        
        # 4. Run LLM
        corrections = run_gemma_analysis(content_blocks)
        
        # 5. Inject Comments
        download_filename = add_comments_to_docx(file_path, corrections)
        
        return jsonify({
            "corrections": corrections,
            "download_url": f"/download/{download_filename}"
        })
        
    except Exception as e:
        print(f"Processing Error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(GENERATED_DIR, filename, as_attachment=True)

#----------------MAIN-----------------
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002)