import os
import json
import base64
from datetime import datetime
from werkzeug.utils import secure_filename
import shutil
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import re
import traceback
import pdfplumber
import docx
import faiss
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer
#from llama_cpp import Llama
from sklearn.metrics.pairwise import cosine_similarity
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import nsdecls
from docx.oxml import parse_xml
import requests
from flask import send_from_directory # Import send_from_directory

########################################
# Global App Setting
########################################
app_settings = {
    "topK": 5,
    "n_ctx": 16384, #25000,
    "seed": 42,
    "max_tokens": 10000,
    "temperature": 0.3,
    "context_text_limit": 2000
}
# Global variables
faiss_index = None
text_chunks = []
current_llm_path = ""

# --- NEW: OLLAMA CONFIGURATION ---
# Make sure this model tag matches what you have in Ollama (e.g., "ollama pull llama3.1:8b-instruct")
OLLAMA_MODEL_NAME = r"gemma3-12b-14:latest"  
OLLAMA_API_URL = "http://localhost:11434/api/generate"
# --- END NEW CONFIG ---

########################################
# Setup Flask
########################################
app = Flask(__name__)
CORS(app)

LOGO_PATH = r"D:\Abhishek_AI_Data\OvTestStudio\Emerson_Logo.png"
OUTPUT_DIR = r"D:\Abhishek_AI_Data\OvTestStudio\output"
UPLOADS_DIR = os.path.join(OUTPUT_DIR, "uploaded_docs")
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'doc', 'docx'}

# Create directories
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(UPLOADS_DIR, exist_ok=True)
FAISS_ROOT_DIR = os.path.join(os.path.dirname(OUTPUT_DIR), "projects")
os.makedirs(FAISS_ROOT_DIR, exist_ok=True)

TEMPLATE_DOCX_PATH = r"D:\Abhishek_AI_Data\OvTestStudio\templates\SRFxxxx_SVTP_rev1.docx"
DESKTOP_DIR = os.path.join(os.path.expanduser('~'), 'Desktop')
os.makedirs(DESKTOP_DIR, exist_ok=True)

#llama_model_path = "/Users/abhishekprasad/Documents/RAG/LLM/Meta-Llama-3.1-8B-Instruct-Q8_0.gguf"
embedding_model_path = r"D:\Abhishek_AI_Data\embeddingGemma300"

# --- Load Models Once ---
embedding_model = SentenceTransformer(embedding_model_path)
# llm = Llama(
#     model_path=llama_model_path, 
#     n_ctx=app_settings['n_ctx'], 
#     n_gpu_layers= -1,#32, 
#     seed=app_settings['seed'],
#     flash_attn=True,
#     )

########################################
# Utility function to check file extension
########################################
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

########################################
# RAG
########################################
def skip_first_n_pages(text, n=3):
    """
    Splits the text by form feed/newpage markers or heuristics,
    and removes the first `n` pages.
    """
    pages = re.split(r"\f|\n\s*\n", text)  # crude way to simulate page breaks
    return "\n\n".join(pages[n:])

def extract_functional_section(text, filename=None):
    import unicodedata

    functional_keywords = [
        "Functional Specification",
        "Functional Features",
        "Functional Requirements",
        "Functional Details",
        "Functional Specs",
        "Functionality"
    ]

    # Normalize
    text = unicodedata.normalize("NFKC", text)
    text = text.replace("\r", "")
    lines = text.split("\n")

    functional_lines = []
    capturing = False
    start_line = None
    end_line = None

    for idx, line in enumerate(lines):
        clean_line = line.strip()

        # Skip empty lines
        if not clean_line:
            continue

        # Match section heading
        if any(k.lower() in clean_line.lower() for k in functional_keywords):
           if re.match(r"^\d+[\.\)]?[\s\t]+", clean_line):
                capturing = True
                start_line = idx
                continue

        # Stop if we hit a new section like "4. Security"
        if capturing:
            if re.match(r"^\d+[\.\)]?\s+(Security|[A-Z][A-Za-z\s]{2,})$", clean_line):
                end_line = idx
                break
            else:
                functional_lines.append(line)

    if functional_lines:
        extracted = "\n".join(functional_lines).strip()
        debug_output = f"""
========= Functional Section Extracted =========
Start Line : {start_line}
End Line   : {end_line or 'EOF'}

--- Extracted Content Start ---
{extracted}
--- Extracted Content End ---
"""

        # Save debug
        if filename:
            base_name = os.path.basename(filename).rsplit('.', 1)[0]
            debug_path = os.path.join(OUTPUT_DIR, f"debug_functional_extract_{base_name}.txt")
            with open(debug_path, "w", encoding="utf-8") as f:
                f.write(debug_output)
            print(f"📝 Debug saved to: {debug_path}")

        return extracted

    print(f"WARNING: Functional section not found in {os.path.basename(filename or 'text')}. Using full text fallback.")
    return None

def extract_text_and_tables_from_pdf(file_path):
    text, tables = "", []
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text() or ""
            tables.extend(page.extract_tables())
    return text, tables

def extract_text_and_tables_from_docx(file_path):
    doc_document = docx.Document(file_path)
    text, tables = [], []
    for para in doc_document.paragraphs:
        if para.text.strip():
            text.append(para.text.strip())
    for table in doc_document.tables:
        table_data = []
        for row in table.rows:
            row_data = [cell.text.strip() for cell in row.cells]
            table_data.append(row_data)
        tables.append(table_data)
    return "\n".join(text), tables

def prepare_combined_text(text, tables):
    """
    Combines text and table data, ensuring all table cells are strings
    to prevent TypeErrors during join operations.
    """
    table_texts = []
    for tbl in tables:
        str_rows = ["\t".join([str(cell or "") for cell in row]) for row in tbl if row]
        table_texts.append("\n".join(str_rows))
        
    return text + "\n\n" + "\n\n".join(table_texts)

def chunk_text_10_2(text, sentences_per_chunk=50, overlap=10):
    sentences = text.split(". ")
    chunks = []
    for i in range(0, len(sentences), sentences_per_chunk - overlap):
        chunk = ". ".join(sentences[i:i + sentences_per_chunk]).strip()
        if chunk:
            chunks.append(chunk)
    return chunks

# def count_tokens_llama(prompt, llm_obj):
#     prompt_bytes = prompt.encode("utf-8")
#     tokens = llm_obj.tokenize(prompt_bytes)
#     return len(tokens)
#     # return len(prompt_bytes)

def process_and_index_document(raw_text, embedding_model_obj, llm_obj=None):
    chunks = chunk_text_10_2(raw_text)
    if not chunks:
        return None, [], 0
    embeddings = embedding_model_obj.encode(chunks, convert_to_tensor=False, prompt_name="Retrieval-document")  #Optimizing for EmbeddingGemma300 model
    dimension = embeddings.shape[1]
    faiss_index = faiss.IndexFlatL2(dimension)
    text_chunks = list(chunks)
    faiss_index.add(np.array(embeddings, dtype=np.float32))

    total_tokens = len(raw_text) 
    return faiss_index, text_chunks, total_tokens

def retrieve_relevant_chunks(query, embedding_model_obj, faiss_index, text_chunks, top_k):
    if not faiss_index or not text_chunks:
        return []
    query_embedding = embedding_model_obj.encode([query], prompt_name="Retrieval-query").astype(np.float32) #Optimization for EmbeddingGemma300 model
    distances, indices = faiss_index.search(query_embedding, top_k)
    relevant_chunks = [text_chunks[i] for i in indices[0]]
    return list(set(relevant_chunks))  # deduplicate

def extract_sdr_test_cases(full_text):
    """
    Finds and parses SDR tables from the full document text to create
    regression test cases.
    """
    sdr_test_cases = []
    sdr_sections = re.findall(r'CAT-\d+ SDRs\n(.*?)(?=\n\n|\Z)', full_text, re.DOTALL)
    
    for section_content in sdr_sections:
        lines = section_content.strip().split('\n')
        for line in lines[1:]:
            parts = line.split(',', 1)
            if len(parts) == 2:
                sdr_number = parts[0].strip()
                sdr_description = parts[1].strip().strip('"')
                if sdr_number.isdigit() or sdr_number.upper().startswith('F'):
                    sdr_test_cases.append({
                        "Test Name": f"SDR {sdr_number}",
                        "Test Steps": [
                            {"Item": "a)", "Step Description": sdr_description, "Initials": "", "P/F/F#": "", "Date": ""}
                        ],
                        "Comments": "Regression test for a previously identified software difficulty report."
                    })
    return sdr_test_cases

##-------------------Llama 3.1 format------------------------------
def prompt_formatter_ieee_829(context, section_name, context_text_limit, user_prompt=""):
    context_text = "\n".join([item[:context_text_limit] for item in context])
    section_prompts = {
        "Features to Be Tested": "Generate the Functional Testing section in a structured format. Include a table with columns: Feature, Test Objective, Configuration, and Expected Behavior. Align each row with a requirement or feature from the context. Mention the test case number from context also",
        "Features Not to Be Tested": "List the features excluded from testing and provide reasons for their exclusion.",
        "Approach": "Describe the testing approach, methodologies, and levels (e.g., unit, integration, system).",
        "Test Environment": "Outline the hardware, software, and tools used in the testing environment.",
        "Entry Criteria": "Define the conditions required before starting the tests.",
        "Exit Criteria": "Specify the conditions required to conclude testing.",
        "Test Case": """Generate detailed functional test cases in the following structured format:

        6.X Test Name: <A concise, descriptive name for the test case objective, e.g., "Verify Successful User Login">
        Test Steps:    Initials:
        a) <Generated Step 1>
        b) <Generated Step 2>
        c) <Generated Step 3>
        d) <Generated Step 4>
        e) <Generated Step 5>
        Comments:
        """
    }
    is_advanced = os.environ.get("ADVANCED_MODE", "0") == "1"

    if section_name == "Test Case" and is_advanced:
        section_prompt = """Generate advanced test cases focused on security, validation of boundary conditions, failover handling, and audit logging."""
    else:
        section_prompt = section_prompts.get(section_name, "Provide detailed content for this section.")
    user_guidance = f"\n\nUser's Additional Guidance: {user_prompt}" if user_prompt else ""

    return f"""<|start_header_id|>system<|end_header_id|>
You are a skilled technical assistant specializing in generating structured test plans based on IEEE 829. For the 'Test Case' section, create a concise and descriptive 'Test Name' that summarizes the primary goal of the test steps. Strictly follow the requested format.{user_guidance}
<|eot_id|><|start_header_id|>user<|end_header_id|>

{section_prompt}

Context:
{context_text}<|eot_id|>
<|start_header_id|>assistant<|end_header_id|>
"""


##-----------------------Gemma 3 format----------------------------
# def prompt_formatter_ieee_829(context, section_name, context_text_limit, user_prompt=""):
#     """
#     Generates a prompt formatted specifically for Gemma 2 (9b/27b) and Gemma 3 (12b).
#     Gemma uses <start_of_turn>user/.../<end_of_turn> structure and generally prefers
#     system instructions embedded in the first user turn.
#     """
    
#     # Truncate context to limit
#     context_text = "\n".join([item[:context_text_limit] for item in context])
    
#     # Define Section Prompts
#     section_prompts = {
#         "Features to Be Tested": "Generate the Functional Testing section in a structured format. Include a table with columns: Feature, Test Objective, Configuration, and Expected Behavior. Align each row with a requirement or feature from the context. Mention the test case number from context also",
#         "Features Not to Be Tested": "List the features excluded from testing and provide reasons for their exclusion.",
#         "Approach": "Describe the testing approach, methodologies, and levels (e.g., unit, integration, system).",
#         "Test Environment": "Outline the hardware, software, and tools used in the testing environment.",
#         "Entry Criteria": "Define the conditions required before starting the tests.",
#         "Exit Criteria": "Specify the conditions required to conclude testing.",
#         "Test Case": """Generate detailed functional test cases in the following structured format:

#         6.X Test Name: <A concise, descriptive name for the test case objective, e.g., "Verify Successful User Login">
#         Test Steps:    Initials:
#         a) <Generated Step 1>
#         b) <Generated Step 2>
#         c) <Generated Step 3>
#         d) <Generated Step 4>
#         e) <Generated Step 5>
#         Comments:
#         """
#     }

#     # Logic for Advanced Mode
#     is_advanced = os.environ.get("ADVANCED_MODE", "0") == "1"

#     if section_name == "Test Case" and is_advanced:
#         section_prompt = """Generate advanced test cases focused on security, validation of boundary conditions, failover handling, and audit logging."""
#     else:
#         section_prompt = section_prompts.get(section_name, "Provide detailed content for this section.")

#     # Handle optional user guidance
#     user_guidance_text = f"\nAdditional Guidance: {user_prompt}" if user_prompt else ""

#     # Construct the System Instruction (Embedded in User turn for Gemma)
#     system_instruction = (
#         "You are a skilled technical assistant specializing in generating structured test plans based on IEEE 829. "
#         "For the 'Test Case' section, create a concise and descriptive 'Test Name' that summarizes the primary goal of the test steps. "
#         "Strictly follow the requested format."
#     )

#     # Gemma 2 / 3 Formatting
#     # Structure: <start_of_turn>user\n{Instruction}\n{Context}\n{Task}<end_of_turn>\n<start_of_turn>model\n
#     return f"""<start_of_turn>user
# {system_instruction}

# {user_guidance_text}

# Task: {section_prompt}

# Context:
# {context_text}<end_of_turn>
# <start_of_turn>model
# """

def parse_test_case_response(response):
    """
    A more robust function to parse the raw text response from the LLM into a structured
    list of test case dictionaries using flexible regular expressions.
    """
    test_case_blocks = re.split(r'(?=6\.\d+\s+Test Name:?)', response, flags=re.IGNORECASE)
    
    structured_data = []
    test_case_number_counter = 1

    for block in test_case_blocks:
        block = block.strip()
        if not block:
            continue

        # Use regex to reliably find the test name, ignoring markdown (**) and case.
        name_match = re.search(r'Test Name:?\s*\**(.+?)\**$', block.split('\n')[0], re.IGNORECASE)
        test_name = name_match.group(1).strip() if name_match else f"Generated Test Case {test_case_number_counter}"

        # Find all lines that look like test steps (e.g., "a)", "b.", etc.)
        steps_matches = re.findall(r'^\s*[a-e][\.\)]\s*(.*)', block, re.MULTILINE | re.IGNORECASE)
        test_steps = [step.strip() for step in steps_matches]

        # Find comments, making the "Comments:" header optional in the capture.
        comments_match = re.search(r'Comments:?\s*(.*)', block, re.IGNORECASE | re.DOTALL)
        comments = comments_match.group(1).strip() if comments_match and comments_match.group(1) else "No comments provided."

        if test_steps:
            # Create the list of dictionaries for the DataFrame
            step_dicts = []
            for i in range(len(test_steps)):
                step_dicts.append({
                    "Item": f"{chr(ord('a') + i)})",
                    "Step Description": test_steps[i],
                    "Initials": "",
                    "P/F/F#": "",
                    "Date": ""
                })

            structured_data.append({
                "Test Case Number": f"6.{test_case_number_counter}",
                "Test Name": test_name,
                "Test Steps": step_dicts,
                "Comments": comments
            })
            test_case_number_counter += 1

    return structured_data

def generate_section(llm_obj, relevant_chunks, section_name, max_tokens, temperature, context_text_limit, n_ctx, user_prompt=""):
    prompt = prompt_formatter_ieee_829(relevant_chunks, section_name, context_text_limit, user_prompt)
    # token_count = count_tokens_llama(prompt, llm_obj)
    # tokens_left = n_ctx - token_count

    # result = llm_obj(prompt, max_tokens=max_tokens, temperature=temperature)
    # response_text = result['choices'][0]['text'].strip()

    # --- NEW OLLAMA CALL ---
    try:
        data = {
            "model": OLLAMA_MODEL_NAME,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
                "seed": app_settings['seed'],
                "top_k": app_settings['topK'],
                "stop": ["<|eot_id|>"] # Stop token for Llama 3
            }
        }
        response = requests.post(OLLAMA_API_URL, json=data)
        response.raise_for_status() # Raise an error for bad responses
        response_text = response.json()['response'].strip()
    
    except requests.exceptions.RequestException as e:
        print(f"--- ERROR: Ollama API call failed! --- {e}")
        print("--- Make sure the Ollama server is running. ---")
        return f"Error: Could not connect to Ollama. {e}"
    # --- END NEW CALL ---

       # ADD THESE LINES FOR DEBUGGING
    if section_name == "Test Case":
        print("\n" + "="*25 + " RAW AI RESPONSE FOR TEST CASES " + "="*25)
        print(response_text)
        print("="*80 + "\n")

    if section_name == "Test Case":
        return parse_test_case_response(response_text)
    else:
        return response_text

def format_test_plan_as_html(planText):
    formatted_html = ""
    sections = planText.split("\n\n")

    for section in sections:
        if "|" in section and "---" in section:
            rows = section.strip().split("\n")
            header = rows[0].split("|")[1:-1]
            data_rows = [row.split("|")[1:-1] for row in rows[2:]]

            table_html = '<table class="min-w-full border-collapse border border-gray-300">'
            table_html += "<thead><tr>" + "".join(
                f'<th class="border px-4 py-2 bg-gray-100">{col.strip()}</th>' for col in header
            ) + "</tr></thead><tbody>"

            for row in data_rows:
                table_html += "<tr>" + "".join(
                    f'<td class="border px-4 py-2">{col.strip()}</td>' for col in row
                ) + "</tr>"
            
            table_html += "</tbody></table><br>"
            formatted_html += table_html
        else:
            formatted_html += f"<p class='mt-4 text-gray-800 font-semibold'>{section.strip()}</p>"

    return formatted_html
    
def format_test_cases_as_html(test_cases):
    if not test_cases:
        return "<p>No test cases generated.</p>"

    html_output = "<h2 class='text-lg font-bold text-gray-800'>Generated Test Cases</h2>"

    for test_case in test_cases:
        html_output += f"""
        <div class='mb-6 p-4 bg-white rounded-lg shadow border border-gray-300'>
            <h3 class='text-md font-semibold text-blue-700 mb-2'>
                {test_case['Test Case Number']}: {test_case['Test Name']}
            </h3>
            <table class='min-w-full border-collapse border border-gray-300'>
                <thead>
                    <tr>
                        <th class='border px-4 py-2 bg-gray-100'>Item</th>
                        <th class='border px-4 py-2 bg-gray-100'>Step Description</th>
                        <th class='border px-4 py-2 bg-gray-100'>Initials</th>
                        <th class='border px-4 py-2 bg-gray-100'>P/F/F#</th>
                        <th class='border px-4 py-2 bg-gray-100'>Date</th>
                    </tr>
                </thead>
                <tbody>
        """

        for step in test_case["Test Steps"]:
            html_output += f"""
                <tr>
                    <td class='border px-4 py-2'>{step['Item']}</td>
                    <td class='border px-4 py-2'>{step['Step Description']}</td>
                    <td class='border px-4 py-2'>{step['Initials']}</td>
                    <td class='border px-4 py-2'>{step['P/F/F#']}</td>
                    <td class='border px-4 py-2'>{step['Date']}</td>
                </tr>
            """

        html_output += """
                </tbody>
            </table>
        </div>
        """

    return html_output

def extract_test_cases_from_text(text):
    # This uses a similar logic to your existing parser but is generalized
    test_case_blocks = re.split(r'(?=Test Case \d+\.\d+:)', text, flags=re.IGNORECASE)
    structured_data = []
    for block in test_case_blocks:
        if not block.strip(): continue
        name_match = re.search(r'Test Case \d+\.\d+:\s*(.*)', block, re.IGNORECASE)
        steps_match = re.findall(r'^[a-e]\)\s*(.*)', block, re.MULTILINE | re.IGNORECASE)
        if name_match and steps_match:
            structured_data.append({
                "name": name_match.group(1).strip(),
                "steps": [s.strip() for s in steps_match]
            })
    return structured_data

def create_docx_report(test_cases, output_path, template_path):
    """
    Generates a .docx report by finding a placeholder in the template
    and inserting the test cases at that location in the correct order.
    """

    # Open the template document instead of creating a new one.
    try:
        doc = Document(template_path)
    except Exception as e:
        print(f"Error opening template file: {e}")
        doc = Document()    # As a fallback, create a blank document

    placeholder_paragraph = None
    for paragraph in doc.paragraphs:
        if '***INSERT_TEST_CASES_HERE***' in paragraph.text:
            placeholder_paragraph = paragraph
            break

    if placeholder_paragraph is None:
        print("ERROR: Placeholder '***INSERT_TEST_CASES_HERE***' not found in the template.")
        doc.save(output_path)
        return

    # Clear the placeholder and add the main heading.
    placeholder_paragraph.text = ""
    runner = placeholder_paragraph.add_run("TEST CASE: Functionality")
    runner.bold = True
    runner.font.name = 'Helvetica'
    runner.font.size = Pt(18)
    placeholder_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER

    current_element_xml = placeholder_paragraph._p

    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    font.size = Pt(12)

    # Loop through test cases
    for test_case in test_cases:
        spacer = doc.add_paragraph()
        current_element_xml.addnext(spacer._p)
        current_element_xml = spacer._p

        # Create the main table with 8 rows and 4 columns
        # Rows: Header, Date/Initial/PFF, 5 steps, Comments
        table = doc.add_table(rows=8, cols=4)
        table.style = 'Table Grid'

        # --- New Test Case Name Row ---
        name_cell = table.cell(0, 0)
        name_cell.merge(table.cell(0, 3))
        tc_name_paragraph = name_cell.paragraphs[0]
        tc_name_run = tc_name_paragraph.add_run(f"{test_case.get('Test Case Number', '')} Test : {test_case.get('Test Name', 'N/A')}")
        tc_name_run.bold = True
        tc_name_paragraph.add_run('\n')

        # Add grey background color to the first row
        for cell in table.rows[0].cells:
            shading_elm = parse_xml(r'<w:shd {} w:fill="D3D3D3"/>'.format(nsdecls('w')))
            cell._tc.get_or_add_tcPr().append(shading_elm)

        # Merge cells for the test case name
        a = table.cell(1, 0)
        b = table.cell(1, 1)
        a.merge(b)
        a.text = " "

        # Populate Date, Initials, Findings
        table.cell(1, 1).text = "Date(s):"
        table.cell(1, 2).text = "Initials:"
        table.cell(1, 3).text = "Findings#"

        # --- Test Steps Rows ---
        steps = test_case.get('Test Steps', [])
        for j in range(5):
            step_row_idx = j + 2

            # Merge cells for the step description
            step_cell_a = table.cell(step_row_idx, 0)
            step_cell_b = table.cell(step_row_idx, 2)
            step_cell_a.merge(step_cell_b)

            # Populate step description
            if j < len(steps):
                step = steps[j]
                step_desc = f"{step.get('Item', '')} {step.get('Step Description', '')}"
                step_cell_a.text = step_desc
            else:
                step_cell_a.text = f"{chr(ord('a') + j)}) "
            
            # Populate P/F/F#
            table.cell(step_row_idx, 3).text = "P/F/F#:"

        # --- Comments Row ---
        comments_cell_a = table.cell(7, 0)
        comments_cell_b = table.cell(7, 3)
        comments_cell_a.merge(comments_cell_b)
        comments_cell_a.text = f"Comments: {test_case.get('Comments', '')}"

        current_element_xml.addnext(table._element)
        current_element_xml = table._element

    # Save the final document
    doc.save(output_path)
    print(f"Report successfully generated at: {output_path}")

########################################
# FLASK ROUTES
########################################
@app.route('/')
def index():
    try:
        with open(LOGO_PATH, 'rb') as lf:
            encoded_logo = base64.b64encode(lf.read()).decode('utf-8')
        return render_template("ui_template.html", logo=encoded_logo)
    except FileNotFoundError:
        return render_template("ui_template.html", logo=None)

@app.route('/apply-settings', methods=['POST'])
def apply_settings():
    try:
        global app_settings, current_llm_path
        new_settings = request.json
        
        app_settings.update({
            "topK": int(new_settings.get("topK", app_settings["topK"])),
            #"n_ctx": int(new_settings.get("n_ctx", 4000)),
            #"seed": int(new_settings.get("seed", 42)),
            "max_tokens": int(new_settings.get("max_tokens", app_settings["max_tokens"])),
            "temperature": float(new_settings.get("temperature", app_settings["temperature"])),
            "context_text_limit": int(new_settings.get("context_text_limit", app_settings["context_text_limit"])),
        })
        return jsonify({"message": "Inference settings applied successfully.", "settings": app_settings})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/history', methods=['GET'])
def get_history_sessions():
    history_path = os.path.join(OUTPUT_DIR, "history")
    history_data = []

    if not os.path.exists(history_path):
        return jsonify([])  
    
    for date_folder in sorted(os.listdir(history_path), reverse=True):
        date_path = os.path.join(history_path, date_folder)
        if not os.path.isdir(date_path):
            continue

        sessions = []
        for file in sorted(os.listdir(date_path)):
            if file.endswith("_plan.txt"):
                time_stamp = file.replace("_plan.txt", "")

                meta_file = os.path.join(date_path, f"{time_stamp}_meta.json")
                session_name = time_stamp

                if os.path.exists(meta_file):
                    with open(meta_file, 'r', encoding='utf-8') as mf:
                        meta = json.load(mf)
                        session_name = meta.get("name", session_name)

                sessions.append({
                    "time": time_stamp,
                    "name": session_name,
                    "plan_path": f"/history/{date_folder}/{time_stamp}_plan.txt",
                    "case_path": f"/history/{date_folder}/{time_stamp}_cases.json"
                })
        if sessions:
            history_data.append({
                "date": date_folder,
                "sessions": sessions
            })

    return jsonify(history_data)

@app.route('/history/load', methods=['POST'])
def load_history_session():
    data = request.get_json()
    plan_file = data.get("plan_path")
    case_file = data.get("case_path")

    try:
        with open(os.path.join(OUTPUT_DIR, plan_file.strip("/")), 'r', encoding='utf-8') as pf:
            plan_text = pf.read()
        
        case_path = os.path.join(OUTPUT_DIR, case_file.strip("/"))
        with open(case_path, 'r', encoding='utf-8') as cf:
            try:
                test_cases = json.load(cf)
            except json.JSONDecodeError as je:
                return jsonify({"error": f"Failed to parse test case JSON file: {je}"}), 500

        formatted_plan = format_test_plan_as_html(plan_text)
        formatted_cases = format_test_cases_as_html(test_cases)

        return jsonify({
            "planText": formatted_plan,
            "testCaseText": formatted_cases,
            "testCaseList": test_cases
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/history/rename', methods=['POST'])
def rename_session():
    data = request.get_json()
    time = data.get("time")
    new_name = data.get("new_name")
    if not time or not new_name:
        return jsonify({"error": "Missing time or new name"}), 400

    history_root = os.path.join(OUTPUT_DIR, "history")
    for date_folder in os.listdir(history_root):
        folder_path = os.path.join(history_root, date_folder)
        if not os.path.isdir(folder_path):
            continue
        meta_path = os.path.join(folder_path, f"{time}_meta.json")
        if os.path.exists(meta_path):
            with open(meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
            meta["name"] = new_name
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f, indent=4)
            return jsonify({"message": "Rename successful"})
    
    return jsonify({"error": "Session not found"}), 404

@app.route('/upload', methods=['POST'])
def upload_files():
    try:
        mode = request.form.get("mode", "standard")
        if 'files[]' not in request.files:
            return jsonify({"error": "No files uploaded"}), 400
        files = request.files.getlist('files[]')
        if not files:
            return jsonify({"error": "No files selected"}), 400

        # Get settings from frontend
        top_k = int(app_settings["topK"])
        max_tokens = int(app_settings["max_tokens"])
        temperature = float(app_settings["temperature"])
        context_text_limit = int(app_settings["context_text_limit"])
        n_ctx = int(app_settings["n_ctx"])
        os.environ["ADVANCED_MODE"] = "1" if mode == "advanced" else "0"

        try:
            settings = json.loads(request.form.get('settings', '{}'))
            selected_sections = settings.get("selectedSections", [])
            user_prompt = settings.get("userPrompt", "")
            # --- THIS IS THE NEWLY ADDED LINE ---
            selected_project = settings.get("selectedProject", "")
        except json.JSONDecodeError:
            selected_sections = []
            user_prompt = ""
            selected_project = "" # Ensure it's defined
        
        if not selected_sections:
            selected_sections = ["Features to Be Tested", "Entry Criteria", "Exit Criteria", "Test Case"]

        # --- Process Uploaded Files (SRF) ---
        temp_upload_dir = os.path.join(OUTPUT_DIR, f"temp_{datetime.now().strftime('%Y%m%d%H%M%S')}")
        os.makedirs(temp_upload_dir, exist_ok=True)
        
        all_raw_texts = []
        functional_texts = []
        
        for f in files:
            if f.filename and allowed_file(f.filename):
                safe_name = secure_filename(f.filename)
                file_path = os.path.join(temp_upload_dir, safe_name)
                f.save(file_path)

                text, tables = ("", [])
                if file_path.endswith(".pdf"): text, tables = extract_text_and_tables_from_pdf(file_path)
                elif file_path.endswith(".docx"): text, tables = extract_text_and_tables_from_docx(file_path)
                else:
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as tf: text = tf.read()
                
                combined_text = prepare_combined_text(text, tables)
                all_raw_texts.append(combined_text) # For SDR extraction

                if mode == "advanced":
                    functional_texts.append(combined_text)
                else:
                    functional = extract_functional_section(combined_text, filename=file_path)
                    # Fallback to full text if section not found
                    functional_texts.append(functional or combined_text)

        shutil.rmtree(temp_upload_dir) # Clean up temp files

        if not functional_texts:
            return jsonify({"error": "No processable text found in documents."}), 400

        rag_input_text = "\n\n".join(functional_texts)
        full_document_text = "\n\n".join(all_raw_texts)

        # --- Create In-Memory Index for SRF ---
        srf_index, srf_chunks, total_tokens = process_and_index_document(rag_input_text, embedding_model, None)
        # Store this as the global index for the /query route to use
        global faiss_index, text_chunks
        faiss_index, text_chunks = srf_index, srf_chunks

        # --- Load Project Repository Index (If selected) ---
        project_index = None
        project_chunks = []
        if selected_project:
            project_dir = os.path.join(FAISS_ROOT_DIR, selected_project)
            index_path = os.path.join(project_dir, "index.faiss")
            chunk_path = os.path.join(project_dir, "text_chunks.json")
            if os.path.exists(index_path) and os.path.exists(chunk_path):
                try:
                    project_index = faiss.read_index(index_path)
                    with open(chunk_path, "r", encoding="utf-8") as f:
                        project_chunks = json.load(f)
                    print(f"--- INFO: Loaded project '{selected_project}' with {len(project_chunks)} chunks for context. ---")
                except Exception as e:
                    print(f"--- WARNING: Failed to load project index '{selected_project}'. Error: {e} ---")
            else:
                print(f"--- WARNING: Project '{selected_project}' selected but index files not found. ---")

        # --- Generation with Hybrid Retrieval ---
        plan_results = {}
        for section in selected_sections:
            # A. Retrieve from the newly uploaded SRF (Primary)
            relevant_srf = retrieve_relevant_chunks(section, embedding_model, srf_index, srf_chunks, top_k)
            print(f"--- Found {len(relevant_srf)} relevant chunks in uploaded SRF.")

            # B. Retrieve from the selected project (Secondary)
            relevant_project = []
            if project_index and project_chunks:
                relevant_project = retrieve_relevant_chunks(section, embedding_model, project_index, project_chunks, top_k)
                print(f"--- Found {len(relevant_project)} relevant chunks in Project '{selected_project}'. ---")

            # C. Combine and de-duplicate. SRF context comes first (higher priority).
            combined_chunks = list(dict.fromkeys(relevant_srf + relevant_project))
            print(f"--- Sending {len(combined_chunks)} total unique chunks to LLM. ---")

            # D. Generate using the combined context
            # result_section = generate_section(
            #     llm_obj=llm,
            #     relevant_chunks=combined_chunks,
            #     section_name=section,
            #     max_tokens=max_tokens,
            #     temperature=temperature,
            #     context_text_limit=context_text_limit,
            #     n_ctx=n_ctx,
            #     user_prompt=user_prompt
            # )
            result_section = generate_section(
                None, combined_chunks, section, max_tokens, temperature,
                context_text_limit, n_ctx, user_prompt
            )
            plan_results[section] = result_section

        # --- (Rest of the function is unchanged from your provided code) ---
        
        # 1. Get the AI-generated functional test cases
        functional_test_cases = plan_results.get("Test Case", [])

        # 2. Extract SDRs from the *full original text*
        sdr_test_cases = extract_sdr_test_cases(full_document_text)
        print(f"--- INFO: Found {len(sdr_test_cases)} SDRs to generate regression tests for. ---")

        # 3. Combine the two lists and renumber everything sequentially
        all_test_cases = functional_test_cases + sdr_test_cases
        for i, test_case in enumerate(all_test_cases):
            test_case["Test Case Number"] = f"6.{i + 1}"

        plan_items = []
        for sec, content in plan_results.items():
            if sec != "Test Case":
                plan_items.append(f"=== {sec} ===\n{str(content)}")
        final_plan_text = "\n\n".join(plan_items)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        test_plan_path = os.path.join(OUTPUT_DIR, f"Test_Plan_{timestamp}.txt")
        test_cases_path = os.path.join(OUTPUT_DIR, f"Test_Cases_{timestamp}.json") # Changed to .json

        with open(test_plan_path, "w", encoding="utf-8") as plan_file:
            plan_file.write(final_plan_text)
        
        with open(test_cases_path, "w", encoding="utf-8") as cases_file:
            json.dump(all_test_cases, cases_file, indent=4)

        history_dir = os.path.join(OUTPUT_DIR, "history", datetime.now().strftime("%Y-%m-%d"))
        os.makedirs(history_dir, exist_ok=True)
        history_timestamp = datetime.now().strftime("%H%M%S")

        history_plan = os.path.join(history_dir, f"{history_timestamp}_plan.txt")
        history_cases = os.path.join(history_dir, f"{history_timestamp}_cases.json")
        shutil.copyfile(test_plan_path, history_plan)
        shutil.copyfile(test_cases_path, history_cases)

        session_meta = {
            "name": files[0].filename.rsplit('.', 1)[0],
            "time": history_timestamp
        }
        meta_path = os.path.join(history_dir, f"{history_timestamp}_meta.json")
        with open(meta_path, "w", encoding="utf-8") as meta_file:
            json.dump(session_meta, meta_file, indent=4)

        formatted_plan_text = format_test_plan_as_html(final_plan_text)
        formatted_test_cases_html = format_test_cases_as_html(all_test_cases)

        return jsonify({
            "message": "RAG-based sections generated successfully",
            "totalTokensInIndex": total_tokens,
            "selectedSections": selected_sections,
            "planText": formatted_plan_text,
            "testCaseList": all_test_cases,
            "testCaseText": formatted_test_cases_html,
            "file_paths": {
                "test_plan": test_plan_path,
                "test_cases": test_cases_path
            }
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@app.route('/query', methods=['POST'])
def query_document():
    data = request.get_json()
    user_query = data.get("query", "").strip()
    selected_project = data.get("project", "").strip()

    if not user_query:
        return jsonify({"error": "Query string is empty"}), 400

    # ====================================================================
    # GenAI-powered Test Automation generation
    # ====================================================================
    if "create test automation" in user_query.lower():
        try:
            # 1. Extract the user's plain-English description of the test
            test_description = user_query.split("create test automation", 1)[-1].strip()
            if not test_description:
                return jsonify({"answer": "Please describe the test you want to generate."})

            master_excel_path = os.path.join("templates", "TestCaseSelector_WC.xlsx")
            
            # 2. Load the library of available functions to give to the AI
            df_functions = pd.read_excel(master_excel_path, sheet_name='TestFunctionList', skiprows=1)
            function_library_context = "\n".join(
                [f"- {row['Test Function Names']}: {row['Description']}" for _, row in df_functions.iterrows()]
            )

            # 3. Construct the prompt for the GenAI
            gen_ai_prompt = f"""<|start_header_id|>system<|end_header_id|>
You are an expert test automation assistant. Your task is to analyze a user's request and create a sequence of test steps using ONLY the functions provided in the `Function Library` context. You must return a valid JSON array of strings, where each string is a function name from the library. Do not add any explanation or introductory text.
<|eot_id|><|start_header_id|>user<|end_header_id|>
Function Library:
{function_library_context}

User Request:
"{test_description}"<|eot_id|>
<|start_header_id|>assistant<|end_header_id|>
"""

            api_data = {
                "model": OLLAMA_MODEL_NAME, 
                "prompt": gen_ai_prompt, 
                "stream": False,
                "options": {
                    "temperature": 0.0, 
                    "num_predict": 1000, 
                    "stop": ["<|eot_id|>"]
                    }
            }
            response = requests.post(OLLAMA_API_URL, json=api_data)
            response.raise_for_status()
            response_text = response.json()['response'].strip()
                
            if response_text.startswith("```json"):
                response_text = response_text.strip("```json\n")

            try:
                function_sequence = json.loads(response_text)
                if not isinstance(function_sequence, list):
                    raise ValueError("AI response was not a JSON list.")
            except (json.JSONDecodeError, ValueError) as e:
                return jsonify({"answer": f"The AI returned an invalid format. Please try rephrasing your request.\n\nRaw AI output:\n{response_text}"})

            # 6. Prepare the new rows for the Excel file
            df_cases = pd.read_excel(master_excel_path, sheet_name='TestCaseFunctions')
            existing_ids = pd.to_numeric(df_cases['Test Case Id'].str.extract(r'TC_(\d+)')[0], errors='coerce').dropna()
            new_id_num = int(existing_ids.max()) + 1 if not existing_ids.empty else 1
            new_test_case_id = f"TC_{new_id_num}"
            
            new_rows = []
            # Create a lookup map for descriptions for efficiency
            description_map = pd.Series(df_functions.Description.values, index=df_functions['Test Function Names']).to_dict()

            for func_name in function_sequence:
                new_rows.append({
                    'Test Case Id': new_test_case_id,
                    'Test Function Name': func_name,
                    'Test Step Descriptor': description_map.get(func_name, "Description not found.")
                })

            # 7. Write the new sequence to the Excel file
            if new_rows:
                new_rows_df = pd.DataFrame(new_rows)

                # a. If there are existing rows, copy the values from the last row for all other columns
                if not df_cases.empty:
                    last_row_values = df_cases.iloc[-1]
                    columns_to_copy = [col for col in df_cases.columns if col not in new_rows_df.columns]
                    for col_name in columns_to_copy:
                        new_rows_df[col_name] = last_row_values[col_name]
                
                # b. Ensure the new DataFrame's column order matches the original file exactly
                new_rows_df = new_rows_df[df_cases.columns]

                updated_df_cases = pd.concat([df_cases, new_rows_df], ignore_index=True)
                with pd.ExcelWriter(master_excel_path, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
                    updated_df_cases.to_excel(writer, sheet_name='TestCaseFunctions', index=False)

            # 8. Process the data for JSON compatibility before sending to UI
            final_steps_list = new_rows_df.to_dict('records')
            processed_data = []
            for row in final_steps_list:
                processed_row = {}
                for key, value in row.items():
                    if pd.isna(value):
                        processed_row[key] = "" # Convert empty/NaN cells to blank strings
                    elif isinstance(value, np.integer):
                        processed_row[key] = int(value) # Convert numpy int to Python int
                    elif isinstance(value, np.floating):
                        processed_row[key] = float(value) # Convert numpy float to Python float
                    else:
                        processed_row[key] = value
                processed_data.append(processed_row)

            return jsonify({
                "answer": f"AI-generated Test-Automation '{new_test_case_id}' is generated and saved successfully.",
                "generated_test_case": {
                    "id": new_test_case_id,
                    "name": f"Test Automation: '{test_description}'",
                    "steps": processed_data #new_rows
                }
            })

        except Exception as e:
            traceback.print_exc()
            return jsonify({"answer": f"An unexpected error occurred during AI generation: {str(e)}"}), 500


    # ====================================================================
    # ROUTE 3: Default RAG query (original fallback)
    # ====================================================================
    else:
        # If the keyword is not found, proceed with the original RAG logic
        try:
            #query_embedding = embedding_model.encode([user_query]).astype(np.float32)   #Optimization for e5-large v2 model
            query_embedding = embedding_model.encode([user_query], prompt_name="Retrieval-query").astype(np.float32)    #Optimization for EmbeddingGemma 300 model

            global faiss_index, text_chunks
            uploaded_results = []
            if faiss_index and text_chunks:
                distances_u, indices_u = faiss_index.search(query_embedding, app_settings["topK"])
                uploaded_results = [text_chunks[i] for i in indices_u[0]]

            project_results = []
            if selected_project:
                project_dir = os.path.join(FAISS_ROOT_DIR, selected_project)
                index_path = os.path.join(project_dir, "index.faiss")
                chunk_path = os.path.join(project_dir, "text_chunks.json")

                if os.path.exists(index_path) and os.path.exists(chunk_path):
                    project_index = faiss.read_index(index_path)
                    with open(chunk_path, "r", encoding="utf-8") as f:
                        project_chunks = json.load(f)

                    distances_p, indices_p = project_index.search(query_embedding, app_settings["topK"])
                    project_results = [project_chunks[i] for i in indices_p[0]]

            all_chunks = uploaded_results + project_results
            unique_chunks = list(dict.fromkeys(all_chunks))
            selected_chunks = unique_chunks[:app_settings["topK"]]

            context_text = "\n\n".join(selected_chunks)
            full_prompt = f"""<|begin_of_text|>
    <|start_header_id|>system<|end_header_id|>
    You are a software testing assistant. Use the given documentation context to answer the user's question. Be concise, relevant, and do not fabricate answers.
    <|start_header_id|>user<|end_header_id|>
    Context:
    {context_text}

    Question: {user_query}
    <|start_header_id|>assistant<|end_header_id|>"""
            
            api_data = {
                    "model": OLLAMA_MODEL_NAME, "prompt": full_prompt, "stream": False,
                    "options": {
                        "temperature": app_settings["temperature"],
                        "num_predict": app_settings["max_tokens"],
                        "seed": app_settings["seed"],
                        "top_k": app_settings["topK"],
                        "stop": ["<|eot_id|>"]
                }
             }
            response = requests.post(OLLAMA_API_URL, json=api_data)
            response.raise_for_status()
            response_text = response.json()['response'].strip()

            return jsonify({
                "query": user_query,
                "project_used": selected_project or "None",
                "answer": response_text
            })

        except Exception as e:
            return jsonify({"error": str(e)}), 500


@app.route('/ingest', methods=['POST'])
def ingest_reference_files():
    project_name = request.form.get("project_name", "").strip()
    if not project_name:
        return jsonify({"error": "Missing project name"}), 400

    if 'files[]' not in request.files:
        return jsonify({"error": "No files uploaded"}), 400

    files = request.files.getlist('files[]')
    if not files:
        return jsonify({"error": "No files selected"}), 400

    project_dir = os.path.join(FAISS_ROOT_DIR, project_name)
    os.makedirs(project_dir, exist_ok=True)

    index_path = os.path.join(project_dir, "index.faiss")
    chunk_path = os.path.join(project_dir, "text_chunks.json")

    if os.path.exists(index_path) and os.path.exists(chunk_path):
        faiss_index_ingest = faiss.read_index(index_path)
        with open(chunk_path, "r", encoding="utf-8") as f:
            text_chunks_ingest = json.load(f)
    else:
        faiss_index_ingest = None
        text_chunks_ingest = []

    saved_file_paths = []
    for f in files:
        if f.filename and allowed_file(f.filename):
            safe_name = secure_filename(f.filename)
            file_path = os.path.join(project_dir, safe_name)
            f.save(file_path)
            saved_file_paths.append(file_path)

    all_new_texts = []
    for path in saved_file_paths:
        if path.endswith(".pdf"):
            text, tables = extract_text_and_tables_from_pdf(path)
        elif path.endswith(".docx"):
            text, tables = extract_text_and_tables_from_docx(path)
        else:
            with open(path, "r", encoding="utf-8", errors="ignore") as tf:
                text = tf.read()
            tables = []

        combined = prepare_combined_text(text, tables)
        all_new_texts.append(combined)

    full_new_text = "\n\n".join(all_new_texts)
    new_chunks = chunk_text_10_2(full_new_text)
    #new_embeddings = embedding_model.encode(new_chunks, convert_to_tensor=False)   #Optimization for e5-large-v2 model
    new_embeddings = embedding_model.encode(new_chunks, convert_to_tensor=False, prompt_name="Retrieval-document")  #Optimization for embeddingGemma300 model

    if faiss_index_ingest is None:
        dimension = new_embeddings.shape[1]
        faiss_index_ingest = faiss.IndexFlatL2(dimension)

    faiss_index_ingest.add(np.array(new_embeddings, dtype=np.float32))
    text_chunks_ingest.extend(new_chunks)

    faiss.write_index(faiss_index_ingest, index_path)
    with open(chunk_path, "w", encoding="utf-8") as f:
        json.dump(text_chunks_ingest, f, indent=4)

    #total_tokens = sum(count_tokens_llama(chunk, llm) for chunk in text_chunks_ingest)

    return jsonify({
        "message": f"Ingested {len(saved_file_paths)} file(s) into FAISS project: {project_name}",
        # "totalTokens": total_tokens,
        "totalChunks": len(text_chunks_ingest)
    })

def extract_custom_test_cases(text):
    """
    Finds and parses test cases based on the specific format "X.Y Test : [Name]".
    """
    blocks = re.split(r'(?=\n?[\d\.]+\s*Test\s*:\s*\**)', text)
    
    structured_data = []
    if not blocks:
        return []

    for block in blocks:
        block = block.strip()
        if not block:
            continue
        
        lines = block.split('\n')
        first_line = lines[0].strip()

        # Extract the test case name, cleaning up the prefix and bold markers.
        name_match = re.search(r'Test\s*:\s*\**(.+?)\**$', first_line, re.IGNORECASE)
        if not name_match:
            continue
            
        name = name_match.group(1).strip()

        # Find all lines that look like steps (starting with a, b, c or *, -)
        steps = re.findall(r'^\s*[-*a-z][\.\)]\s+(.*)', block, re.MULTILINE | re.IGNORECASE)
        
        if name and steps:
            structured_data.append({
                "name": name,
                "steps": [s.strip() for s in steps]
            })
            
    return structured_data

@app.route('/projects', methods=['GET'])
def list_projects():
    try:
        project_dirs = [
            name for name in os.listdir(FAISS_ROOT_DIR)
            if os.path.isdir(os.path.join(FAISS_ROOT_DIR, name))
        ]
        return jsonify({"projects": sorted(project_dirs)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/save-report', methods=['POST'])
def save_report():
    """
    Receives generated content from the frontend and saves it as a DOCX file
    directly to the user's desktop.
    """
    try:
        data = request.get_json()
        test_cases = data.get('testCases', [])

        if not test_cases:
            return jsonify({"error": "No test case data provided."}), 400
        
        # Create a unique filename for the desktop
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"Test_Report_{timestamp}.docx"
        desktop_path = os.path.join(DESKTOP_DIR, filename)
        
        # Use the new function to create the DOCX file on the desktop
        create_docx_report(test_cases, desktop_path, TEMPLATE_DOCX_PATH)
        
        return jsonify({
            "message": f"Successfully saved report to your desktop as {filename}",
            "path": desktop_path
            })

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": f"Failed to save report: {str(e)}"}), 500

@app.route('/compare', methods=['POST'])
def compare_test_cases():
    try:
        if 'file1' not in request.files or 'file2' not in request.files:
            return jsonify({"error": "Please upload two files for comparison."}), 400

        file1 = request.files['file1']
        file2 = request.files['file2']

        if not (file1.filename and allowed_file(file1.filename)) or not (file2.filename and allowed_file(file2.filename)):
            return jsonify({"error": "Invalid file type. Please use .txt, .pdf, or .docx."}), 400

        def get_full_text(file_storage):
            """Helper function to extract and combine text from any supported file type."""
            text, tables = "", []
            filename = secure_filename(file_storage.filename)
            
            if filename.endswith('.pdf'):
                text, tables = extract_text_and_tables_from_pdf(file_storage)
            
            elif filename.endswith('.docx'):
                text, tables = extract_text_and_tables_from_docx(file_storage)
            
            elif filename.endswith('.txt'):
                text = file_storage.read().decode('utf-8', errors='ignore')
            
            return prepare_combined_text(text, tables)

        text1 = get_full_text(file1)
        text2 = get_full_text(file2)
        test_cases1 = extract_custom_test_cases(text1)
        test_cases2 = extract_custom_test_cases(text2)


        # --- DEBUG PRINTOUT:---
        print("\n" + "="*20 + " DEBUG: Comparison Extraction " + "="*20)
        print(f"Found {len(test_cases1)} test cases in: {file1.filename}")
        print(f"Names: {[tc['name'] for tc in test_cases1]}")
        print(f"Found {len(test_cases2)} test cases in: {file2.filename}")
        print(f"Names: {[tc['name'] for tc in test_cases2]}")
        print("="*70 + "\n")
        # --- END DEBUG ---

        if not test_cases1 or not test_cases2:
            return jsonify({"error": "Could not extract test cases from one or both documents."}), 400

        # Get embeddings for all test case names
        names1 = [tc['name'] for tc in test_cases1]
        names2 = [tc['name'] for tc in test_cases2]
        
        #-------Optimized for e5-large-v2 model-------------
        # embeddings1 = embedding_model.encode(names1)
        # embeddings2 = embedding_model.encode(names2)
        #---------------------------------------------------

        #-------Optimized for EmbeddingGemma300 model-----------------------
        embeddings1 = embedding_model.encode(names1, prompt_name="STS")
        embeddings2 = embedding_model.encode(names2, prompt_name="STS")
        #-------------------------------------------------------------------

        # Calculate cosine similarity between all pairs
        similarity_matrix = cosine_similarity(embeddings1, embeddings2)

        matches = []
        used_indices2 = set()
        unique_to_1 = list(range(len(test_cases1)))

        # Find the best match for each case in file 1
        for i in range(len(test_cases1)):
            best_match_idx = -1
            highest_similarity = 0.90  # Similarity threshold
            
            for j in range(len(test_cases2)):
                if j not in used_indices2 and similarity_matrix[i][j] > highest_similarity:
                    highest_similarity = similarity_matrix[i][j]
                    best_match_idx = j
            
            if best_match_idx != -1:
                matches.append({
                    "case1": test_cases1[i],
                    "case2": test_cases2[best_match_idx],
                    "similarity": f"{highest_similarity * 100:.2f}"
                })
                used_indices2.add(best_match_idx)
                if i in unique_to_1:
                    unique_to_1.remove(i)

        # Identify cases unique to file 2
        unique_to_2_indices = set(range(len(test_cases2))) - used_indices2
        unique_cases_1 = [test_cases1[i] for i in unique_to_1]
        unique_cases_2 = [test_cases2[i] for i in unique_to_2_indices]

        # Calculate overall similarity score
        overall_similarity = (len(matches) / max(len(test_cases1), len(test_cases2))) * 100 if max(len(test_cases1), len(test_cases2)) > 0 else 0
        
        return jsonify({
            "message": "Comparison complete.",
            "overall_similarity": round(overall_similarity, 2),
            "matches": sorted(matches, key=lambda x: x['similarity'], reverse=True),
            "unique_file1": unique_cases_1,
            "unique_file2": unique_cases_2,
            "file1_name": file1.filename,
            "file2_name": file2.filename
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": f"An unexpected error occurred during comparison: {str(e)}"}), 500

@app.route('/format-details', methods=['POST'])
def format_details_text():
    data = request.get_json()
    raw_text = data.get("text", "")

    if not raw_text:
        return jsonify({"formatted_text": ""})

    # This prompt instructs the AI to act as an HTML formatter
    prompt = f"""<|start_header_id|>system<|end_header_id|>
You are an expert HTML formatting assistant. Your task is to take a block of plain text and wrap any phrase that acts as a header (typically a few words ending with a colon) in `<strong class="font-semibold text-gray-900">` and `</strong>` tags. Do not alter the text content, add explanations, or use any other HTML tags. Preserve all original line breaks.
<|eot_id|><|start_header_id|>user<|end_header_id|>
Format this text:
{raw_text}<|eot_id|>
<|start_header_id|>assistant<|end_header_id|>
"""

    try:
        api_data = {
            "model": OLLAMA_MODEL_NAME, "prompt": prompt, "stream": False,
            "options": {"temperature": 0.0, "num_predict": 1000, "stop": ["<|eot_id|>"]}
        }
        response = requests.post(OLLAMA_API_URL, json=api_data)
        response.raise_for_status()
        formatted_text = response.json()['response'].strip()
        return jsonify({"formatted_text": formatted_text})
    except Exception as e:
        print(f"LLM formatting failed: {e}. Returning raw text.")
        return jsonify({"formatted_text": raw_text})


# 1. Add a route to serve the SDR UI
@app.route('/sdr-studio')
def sdr_studio():
    # Assumes sdr_ui.html is in the 'templates' folder. 
    # If it's a raw file, you might need to use send_file or move it to templates.
    return render_template("sdr_ui.html")

# 2. Add the API endpoint to handle SDR Selection and Generation
@app.route('/generate_from_sdrs', methods=['POST'])
def generate_from_sdrs():
    try:
        data = request.json
        selected_sdrs = data.get('sdrs', [])

        if not selected_sdrs:
            return jsonify({"error": "No SDRs provided"}), 400

        # A. Format SDRs into a text block (Simulating a document)
        formatted_text = "=== Functional Specification based on Selected SDRs ===\n\n"
        for sdr in selected_sdrs:
            formatted_text += f"SDR ID: {sdr.get('ID', 'N/A')}\n"
            formatted_text += f"Title: {sdr.get('Title', 'N/A')}\n"
            formatted_text += f"State: {sdr.get('State', 'N/A')}\n"
            formatted_text += f"Description: {sdr.get('Description', 'N/A')}\n"
            formatted_text += f"Resolution Steps: {sdr.get('Resolution', 'N/A')}\n"
            formatted_text += f"Resolution: {sdr.get('Internal Resolution', 'N/A')}\n"
            formatted_text += f"Severity Justification: {sdr.get('Severity Justification', 'N/A')}\n"
            formatted_text += "-" * 40 + "\n\n"

        # B. Update Global Context (So Chat/Query works immediately)
        global faiss_index, text_chunks
        # Index the SDR text
        new_index, new_chunks, total_tokens = process_and_index_document(formatted_text, embedding_model, None)
        faiss_index = new_index
        text_chunks = new_chunks
        
        print(f"--- Context updated with {len(selected_sdrs)} SDRs. Total Tokens: {total_tokens} ---")

        # C. Generate Test Cases using LLM
        # We reuse the existing logic but force the section to "Test Case"
        test_case_result = generate_section(
            None, 
            new_chunks, # Use all chunks from the SDRs
            "Test Case", 
            app_settings['max_tokens'], 
            app_settings['temperature'], 
            app_settings['context_text_limit'], 
            app_settings['n_ctx'], 
            user_prompt="Generate regression test cases specifically for these reported SDR bugs."
        )

        # D. Structure and Save the Plan
        all_test_cases = test_case_result # This is already a list of dicts from generate_section

        # Create a simple plan text wrapper
        final_plan_text = f"=== Test Case ===\nGenerated based on {len(selected_sdrs)} selected SDRs.\n\n"
        # (Optional: You could convert the test_case_result back to text here for the plan file if needed)

        # Generate Timestamps and Filenames
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        history_timestamp = datetime.now().strftime("%H%M%S")
        history_date = datetime.now().strftime("%Y-%m-%d")

        # Paths
        history_dir = os.path.join(OUTPUT_DIR, "history", history_date)
        os.makedirs(history_dir, exist_ok=True)

        history_plan_path = os.path.join(history_dir, f"{history_timestamp}_plan.txt")
        history_cases_path = os.path.join(history_dir, f"{history_timestamp}_cases.json")
        meta_path = os.path.join(history_dir, f"{history_timestamp}_meta.json")

        # Save Files
        with open(history_plan_path, "w", encoding="utf-8") as f:
            f.write(final_plan_text)
        
        with open(history_cases_path, "w", encoding="utf-8") as f:
            json.dump(all_test_cases, f, indent=4)

        # Save Metadata (So it appears in the History Sidebar)
        session_name = f"SDR Analysis ({len(selected_sdrs)} Items)"
        session_meta = {
            "name": session_name,
            "time": history_timestamp,
            "source": "SDR_UI"
        }
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(session_meta, f, indent=4)

        return jsonify({
            "message": "SDRs Processed Successfully",
            "redirect_url": "/", # Redirect to the main Test Studio
            "session_name": session_name
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    from waitress import serve
    # The host '0.0.0.0' makes the server accessible from other computers
    print("--- Test Studio Server starting on http://0.0.0.0:5001 ---")
    print("--- Close this window or press Ctrl+C to stop the server. ---")
    serve(app, host="0.0.0.0", port=5001)