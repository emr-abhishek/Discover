document.addEventListener('DOMContentLoaded', () => {
    const iconRowWrappers = document.querySelectorAll('.icon-row-wrapper');
    const HOVER_DELAY = 500; // 0.5 second delay
    let hoverTimer;
    let currentVisibleBox = null;

    // --- Logic to show the description box ---
    const showDescriptionBox = (icon) => {
        // Find the description box for the current row
        const wrapper = icon.closest('.icon-row-wrapper');
        const descriptionBox = wrapper.querySelector('.description-box');

        const descriptionText = icon.querySelector('.product-description')?.innerHTML;

        if (descriptionBox && descriptionText) {
            if (currentVisibleBox && currentVisibleBox !== descriptionBox) {
                currentVisibleBox.classList.remove('visible');
            }

            descriptionBox.innerHTML = `<p>${descriptionText}</p>`;
            descriptionBox.classList.add('visible');
            currentVisibleBox = descriptionBox;
            const iconRect = icon.getBoundingClientRect();
            const wrapperRect = wrapper.getBoundingClientRect();
            const iconCenter = iconRect.left + (iconRect.width / 2);
            const arrowPosition = iconCenter - wrapperRect.left; // Position relative to the wrapper

            // Set a CSS variable for the arrow's left position
            descriptionBox.style.setProperty('--arrow-left', `${arrowPosition}px`);
        }
    };

    // --- Logic to hide the description box ---
    const hideDescriptionBox = () => {
        if (currentVisibleBox) {
            currentVisibleBox.classList.remove('visible');
            currentVisibleBox = null;
        }
    };

    // --- Attach event listeners to each row ---
    iconRowWrappers.forEach(wrapper => {
        const icons = wrapper.querySelectorAll('.product-icon');

        icons.forEach(icon => {
            // When the mouse enters an icon, start the timer
            icon.addEventListener('mouseenter', () => {
                clearTimeout(hoverTimer); // Clear any existing timer
                hoverTimer = setTimeout(() => showDescriptionBox(icon), HOVER_DELAY);
            });

            // When the mouse clicks an icon, open the link and hide the box
            icon.addEventListener('click', () => {
                const url = icon.dataset.url;
                const appIdToLaunch = icon.dataset.appId;

                if (url) {
                    window.open(url, '_blank');
                }

                if (appIdToLaunch) {
                fetch(`http://localhost:6001/launch/${appIdToLaunch}`)
                    .then(response => {
                        if (response.ok) {
                            console.log(`Successfully sent launch request for ${appIdToLaunch}`);
                        } 
                        else {
                            console.error(`Failed to launch ${appIdToLaunch}`);
                        }
                    })
                    .catch(error => console.error('Error connecting to helper server:', error));
            }
                clearTimeout(hoverTimer);
                hideDescriptionBox();
            });
        });

        // When the mouse leaves the entire row area, clear the timer and hide the box
        wrapper.addEventListener('mouseleave', () => {
            clearTimeout(hoverTimer);
            hideDescriptionBox();
        });
    });
});