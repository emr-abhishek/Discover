import os
import subprocess
from flask import Flask, Response

# --- CONFIGURE YOUR APPLICATIONS HERE ---
# Use simple names (keys) and the full path to the .exe (values)
APPLICATIONS = {
    "PSA_App": r"D:\Debug\StartUp.exe",
}
# -----------------------------------------

app = Flask(__name__)

@app.route('/launch/<app_id>')
def launch_app(app_id):
    if app_id in APPLICATIONS:
        try:
            # Use os.startfile for a simple, non-blocking launch
            os.startfile(APPLICATIONS[app_id])
            print(f"Successfully launched {app_id}")
            # Send a success response back to the webpage
            resp = Response("SUCCESS", status=200)
        except FileNotFoundError:
            print(f"Error: Could not find the file for {app_id}")
            resp = Response("ERROR: File not found", status=404)
    else:
        print(f"Error: Unknown app_id '{app_id}'")
        resp = Response("ERROR: Unknown application ID", status=400)

    # Add a CORS header to allow the request from your webpage
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp

if __name__ == '__main__':
    print("Starting helper server on http://localhost:5001")
    app.run(port=6001)