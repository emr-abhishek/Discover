"""
Evaluation Module for Gemma Pipeline
Handles retrieval evaluation with various metrics
"""

import json
import statistics
from typing import List, Dict, Any
from pathlib import Path

from .config import GemmaConfig
from .retriever import GemmaRetriever
from .reranker import GemmaReranker


class GemmaEvaluator:
    """Evaluate retrieval performance"""
    
    def __init__(self, config: GemmaConfig = None, use_reranking: bool = False):
        """
        Initialize evaluator
        
        Args:
            config: Pipeline configuration
            use_reranking: Enable cross-encoder reranking
        """
        self.config = config or GemmaConfig()
        self.retriever = GemmaRetriever(config)
        self.use_reranking = use_reranking
        self.reranker = GemmaReranker(config) if use_reranking else None
    
    @staticmethod
    def precision_at_k(retrieved_ids: List[str], relevant_ids: List[str], k: int) -> float:
        """Calculate Precision@K"""
        if k == 0:
            return 0.0
        retrieved_k = retrieved_ids[:k]
        relevant_set = set(relevant_ids)
        hits = sum(1 for doc_id in retrieved_k if doc_id in relevant_set)
        return hits / k
    
    @staticmethod
    def recall_at_k(retrieved_ids: List[str], relevant_ids: List[str], k: int) -> float:
        """Calculate Recall@K"""
        if len(relevant_ids) == 0:
            return 0.0
        retrieved_k = retrieved_ids[:k]
        relevant_set = set(relevant_ids)
        hits = sum(1 for doc_id in retrieved_k if doc_id in relevant_set)
        return hits / len(relevant_ids)
    
    @staticmethod
    def f1_at_k(retrieved_ids: List[str], relevant_ids: List[str], k: int) -> float:
        """Calculate F1@K"""
        precision = GemmaEvaluator.precision_at_k(retrieved_ids, relevant_ids, k)
        recall = GemmaEvaluator.recall_at_k(retrieved_ids, relevant_ids, k)
        if precision + recall == 0:
            return 0.0
        return 2 * (precision * recall) / (precision + recall)
    
    @staticmethod
    def mean_reciprocal_rank(retrieved_ids: List[str], relevant_ids: List[str]) -> float:
        """Calculate Mean Reciprocal Rank (MRR)"""
        relevant_set = set(relevant_ids)
        for i, doc_id in enumerate(retrieved_ids, 1):
            if doc_id in relevant_set:
                return 1.0 / i
        return 0.0
    
    @staticmethod
    def ndcg_at_k(retrieved_ids: List[str], relevant_ids: List[str], k: int) -> float:
        """Calculate Normalized Discounted Cumulative Gain (nDCG@K)"""
        retrieved_k = retrieved_ids[:k]
        relevant_set = set(relevant_ids)
        
        # DCG
        dcg = 0.0
        for i, doc_id in enumerate(retrieved_k, 1):
            if doc_id in relevant_set:
                dcg += 1.0 / (i + 1).bit_length()  # log2(i+1)
        
        # IDCG (ideal DCG)
        idcg = 0.0
        for i in range(min(len(relevant_ids), k)):
            idcg += 1.0 / (i + 2).bit_length()  # log2(i+1)
        
        if idcg == 0:
            return 0.0
        
        return dcg / idcg
    
    @staticmethod
    def average_precision(retrieved_ids: List[str], relevant_ids: List[str]) -> float:
        """Calculate Average Precision (AP)"""
        relevant_set = set(relevant_ids)
        
        precision_sum = 0.0
        num_hits = 0
        
        for i, doc_id in enumerate(retrieved_ids, 1):
            if doc_id in relevant_set:
                num_hits += 1
                precision_sum += num_hits / i
        
        if num_hits == 0:
            return 0.0
        
        return precision_sum / len(relevant_ids)
    
    def evaluate_single_query(
        self,
        query: str,
        relevant_ids: List[str],
        k_values: List[int] = None,
        retrieval_k: int = 30
    ) -> Dict[str, float]:
        """
        Evaluate a single query
        
        Args:
            query: Query string
            relevant_ids: List of relevant document IDs
            k_values: List of K values for evaluation
            retrieval_k: Number of candidates for reranking (if enabled)
        
        Returns:
            Dictionary of metrics
        """
        k_values = k_values or self.config.K_VALUES
        max_k = max(k_values)
        
        # Query retrieval system (with optional reranking)
        if self.use_reranking and self.reranker:
            results = self.reranker.retrieve_and_rerank(
                self.retriever,
                query,
                retrieval_k=retrieval_k,
                rerank_k=max_k
            )
        else:
            results = self.retriever.query(query, n_results=max_k)
        
        if not results or not results['ids'] or len(results['ids']) == 0:
            return {f'P@{k}': 0.0 for k in k_values}
        
        retrieved_ids = results['ids'][0]
        
        # Calculate metrics
        metrics = {}
        
        for k in k_values:
            metrics[f'P@{k}'] = self.precision_at_k(retrieved_ids, relevant_ids, k)
            metrics[f'R@{k}'] = self.recall_at_k(retrieved_ids, relevant_ids, k)
            metrics[f'F1@{k}'] = self.f1_at_k(retrieved_ids, relevant_ids, k)
            metrics[f'nDCG@{k}'] = self.ndcg_at_k(retrieved_ids, relevant_ids, k)
        
        metrics['MRR'] = self.mean_reciprocal_rank(retrieved_ids, relevant_ids)
        metrics['AP'] = self.average_precision(retrieved_ids, relevant_ids)
        
        return metrics
    
    def evaluate_ground_truth(
        self,
        ground_truth_file: str = None,
        k_values: List[int] = None,
        retrieval_k: int = 30
    ) -> Dict[str, Any]:
        """
        Evaluate against ground truth file
        
        Args:
            ground_truth_file: Path to ground truth JSON file
            k_values: List of K values for evaluation
            retrieval_k: Number of candidates for reranking (if enabled)
        
        Returns:
            Dictionary with evaluation results
        """
        ground_truth_file = ground_truth_file or self.config.GROUND_TRUTH_FILE
        k_values = k_values or self.config.K_VALUES
        
        # Load ground truth
        print(f"Loading ground truth from {ground_truth_file}...")
        
        if not Path(ground_truth_file).exists():
            raise FileNotFoundError(f"Ground truth file not found: {ground_truth_file}")
        
        with open(ground_truth_file, 'r') as f:
            ground_truth = json.load(f)
        
        print(f"Loaded {len(ground_truth)} test queries\n")
        
        # Evaluate each query
        mode_str = "with reranking" if self.use_reranking else "standard"
        print(f"Evaluating queries ({mode_str})...")
        all_metrics = []
        query_details = []
        
        total = len(ground_truth)
        for idx, item in enumerate(ground_truth, 1):
            query = item['query']
            # Handle both key names for backwards compatibility
            relevant_ids = item.get('relevant_document_ids') or item.get('ids', [])
            
            if idx % 10 == 0 or idx == total:
                print(f"  Evaluating query {idx}/{total}...")
            
            metrics = self.evaluate_single_query(query, relevant_ids, k_values, retrieval_k)
            all_metrics.append(metrics)
            
            query_details.append({
                'query': query,
                'relevant_ids': relevant_ids,
                'metrics': metrics
            })
        
        print(f"✅ Evaluation complete\n")
        
        # Calculate aggregate metrics
        aggregate_metrics = {}
        
        for metric_name in all_metrics[0].keys():
            values = [m[metric_name] for m in all_metrics]
            aggregate_metrics[metric_name] = {
                'mean': statistics.mean(values),
                'median': statistics.median(values),
                'stdev': statistics.stdev(values) if len(values) > 1 else 0.0,
                'min': min(values),
                'max': max(values)
            }
        
        # Prepare results
        results = {
            'model_name': self.config.MODEL_NAME,
            'mode': 'reranked' if self.use_reranking else 'standard',
            'num_queries': len(ground_truth),
            'k_values': k_values,
            'retrieval_k': retrieval_k if self.use_reranking else None,
            'aggregate_metrics': aggregate_metrics,
            'per_query_results': query_details
        }
        
        return results
    
    def save_results(self, results: Dict[str, Any], output_file: str = None):
        """
        Save evaluation results to JSON file
        
        Args:
            results: Evaluation results dictionary
            output_file: Output file path
        """
        output_file = output_file or self.config.EVALUATION_RESULTS
        
        with open(output_file, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"✅ Results saved to {output_file}")
    
    def print_summary(self, results: Dict[str, Any]):
        """
        Print evaluation summary
        
        Args:
            results: Evaluation results dictionary
        """
        print("\n" + "="*80)
        mode = results.get('mode', 'standard')
        print(f"EVALUATION SUMMARY - {results['model_name']} ({mode})")
        print("="*80)
        print(f"Number of test queries: {results['num_queries']}")
        print(f"K values: {results['k_values']}")
        if results.get('retrieval_k'):
            print(f"Retrieval K (for reranking): {results['retrieval_k']}")
        print("\nAggregate Metrics (Mean):")
        print("-"*80)
        
        aggregate = results['aggregate_metrics']
        
        # Precision
        print("\nPrecision@K:")
        for k in results['k_values']:
            mean_val = aggregate[f'P@{k}']['mean']
            print(f"  P@{k:2d}: {mean_val:.4f}")
        
        # Recall
        print("\nRecall@K:")
        for k in results['k_values']:
            mean_val = aggregate[f'R@{k}']['mean']
            print(f"  R@{k:2d}: {mean_val:.4f}")
        
        # F1
        print("\nF1@K:")
        for k in results['k_values']:
            mean_val = aggregate[f'F1@{k}']['mean']
            print(f"  F1@{k:2d}: {mean_val:.4f}")
        
        # nDCG
        print("\nnDCG@K:")
        for k in results['k_values']:
            mean_val = aggregate[f'nDCG@{k}']['mean']
            print(f"  nDCG@{k:2d}: {mean_val:.4f}")
        
        # MRR and MAP
        print(f"\nMRR: {aggregate['MRR']['mean']:.4f}")
        print(f"MAP: {aggregate['AP']['mean']:.4f}")
        
        print("="*80 + "\n")
