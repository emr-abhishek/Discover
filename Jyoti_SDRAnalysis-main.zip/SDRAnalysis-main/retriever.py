"""
Retrieval Module for Gemma Pipeline
Handles ChromaDB queries and retrieval
"""

import chromadb
import torch
from sentence_transformers import SentenceTransformer
from typing import List, Dict, Any, Tuple
from pathlib import Path

from .config import GemmaConfig


class GemmaRetriever:
    """Handle retrieval from ChromaDB"""
    
    def __init__(self, config: GemmaConfig = None):
        """Initialize retriever"""
        self.config = config or GemmaConfig()
        self.model = None
        self.collection = None
    
    def load_model(self):
        """Load Gemma embedding model"""
        if self.model:
            return  # Already loaded
        
        print(f"Loading Gemma model for retrieval...")
        
        if not Path(self.config.MODEL_PATH).exists():
            raise FileNotFoundError(f"Model not found at: {self.config.MODEL_PATH}")
        
        # Detect device
        if torch.cuda.is_available():
            device = 'cuda'
        elif torch.backends.mps.is_available():
            device = 'mps'
        else:
            device = 'cpu'
        
        self.model = SentenceTransformer(
            self.config.MODEL_PATH,
            device=device,
            trust_remote_code=True
        )
        
        print(f"✅ Model loaded (dimension: {self.model.get_sentence_embedding_dimension()})")
    
    def connect_chromadb(self):
        """Connect to existing ChromaDB collection"""
        if self.collection:
            return  # Already connected
        
        print(f"Connecting to ChromaDB...")
        
        if not Path(self.config.CHROMADB_PATH).exists():
            raise FileNotFoundError(f"ChromaDB not found at: {self.config.CHROMADB_PATH}")
        
        client = chromadb.PersistentClient(path=self.config.CHROMADB_PATH)
        self.collection = client.get_collection(name=self.config.COLLECTION_NAME)
        
        print(f"✅ Connected to collection: {self.config.COLLECTION_NAME}")
        print(f"   Total documents: {self.collection.count()}\n")
    
    def query(self, query_text: str, n_results: int = 10) -> Dict[str, Any]:
        """
        Query ChromaDB and return results
        
        Args:
            query_text: Query string
            n_results: Number of results to return
        
        Returns:
            Dictionary with query results
        """
        if not self.model:
            self.load_model()
        
        if not self.collection:
            self.connect_chromadb()
        
        try:
            # Generate query embedding
            query_embedding = self.model.encode(query_text, normalize_embeddings=True)
            
            # Query ChromaDB
            results = self.collection.query(
                query_embeddings=[query_embedding.tolist()],
                n_results=n_results
            )
            
            return results
        
        except Exception as e:
            print(f"  ⚠️  Query error: {e}")
            return {'ids': [[]], 'distances': [[]], 'metadatas': [[]], 'documents': [[]]}
    
    def query_batch(self, queries: List[str], n_results: int = 10) -> List[Dict[str, Any]]:
        """
        Query multiple queries in batch
        
        Args:
            queries: List of query strings
            n_results: Number of results per query
        
        Returns:
            List of query results
        """
        if not self.model:
            self.load_model()
        
        if not self.collection:
            self.connect_chromadb()
        
        results = []
        total = len(queries)
        
        for idx, query in enumerate(queries, 1):
            if idx % 10 == 0 or idx == total:
                print(f"  Querying {idx}/{total}...", end='\r')
            
            result = self.query(query, n_results)
            results.append(result)
        
        print(f"  ✅ Completed {total} queries")
        return results
    
    def get_document_by_id(self, doc_id: str) -> Dict[str, Any]:
        """
        Retrieve a document by its ID
        
        Args:
            doc_id: Document ID
        
        Returns:
            Document data
        """
        if not self.collection:
            self.connect_chromadb()
        
        try:
            result = self.collection.get(ids=[doc_id])
            if result and result['ids']:
                return {
                    'id': result['ids'][0],
                    'metadata': result['metadatas'][0] if result['metadatas'] else {},
                    'document': result['documents'][0] if result['documents'] else ''
                }
            return None
        except Exception as e:
            print(f"  ⚠️  Error retrieving document {doc_id}: {e}")
            return None
