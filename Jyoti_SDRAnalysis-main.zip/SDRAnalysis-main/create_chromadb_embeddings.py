"""
Advanced SDR Embedding and ChromaDB Storage Script
Uses Alibaba GTE-Large model with optimized preprocessing for maximum retrieval accuracy
"""

import json
import re
import time
import sys
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings
from typing import List, Dict, Any
import numpy as np
from tqdm import tqdm
import torch

# ============================================================================
# CONFIGURATION
# ============================================================================

# Model Configuration (defaults - can be overridden)
MODEL_PATH = "/Users/jyotigaur/Documents/my_work/codes/EmbeddingModels/embeddinggemma-300m"
INPUT_JSON_FILE = "sdr_dataset.json"
CHROMADB_PATH = "./chromadb_storage"
COLLECTION_NAME = "sdr_collection"

# Batch processing
BATCH_SIZE = 8  # Reduced to 8 for MPS stability (was 16)

# Fields to embed with priority weighting
# Higher priority fields will be repeated or emphasized in the embedding text
EMBEDDING_FIELDS_CONFIG = {
    # Format: 'field_name': (priority_weight, field_label)
    'Title': (3, 'Title'),  # Highest priority - most descriptive
    'Description': (3, 'Description'),  # Highest priority
    'Work Item Type': (1, 'Type'),
    'Product': (2, 'Product'),  # High priority
    'Product Category': (2, 'Category'),  # High priority
    'Internal Resolution': (2, 'Resolution'),  # High priority - contains fix details
    'Severity': (2, 'Severity'),  # High priority if available
    'Product Component': (1, 'Component'),
    'Product Problem Type': (1, 'Problem Type'),
    'State': (1, 'State'),
}

# Additional metadata fields to include (without weighting)
METADATA_FIELDS = [
    'Priority', 'Reason', 'Reporting Source', 'Phase',
    'Product Version', 'Product State', 'Submitting Organization'
]

# ============================================================================
# TEXT PREPROCESSING FUNCTIONS
# ============================================================================

def clean_text(text: str) -> str:
    """
    Advanced text cleaning for better embedding quality
    """
    if not text or text == "":
        return ""
    
    # Convert to string
    text = str(text)
    
    # Remove HTML tags
    text = re.sub(r'<[^>]+>', ' ', text)
    
    # Remove URLs
    text = re.sub(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', ' ', text)
    
    # Remove email addresses
    text = re.sub(r'\S+@\S+', ' ', text)
    
    # Remove special characters but keep important punctuation
    text = re.sub(r'[^\w\s\-.,;:()\[\]\/]', ' ', text)
    
    # Remove multiple spaces
    text = re.sub(r'\s+', ' ', text)
    
    # Remove leading/trailing whitespace
    text = text.strip()
    
    return text

def extract_keywords(text: str) -> List[str]:
    """
    Extract important technical keywords from text
    """
    if not text or text == "":
        return []
    
    # Truncate very long text to prevent regex slowdown
    if len(text) > 5000:
        text = text[:5000]
    
    # Common technical patterns in SDR descriptions
    # Using simpler, more efficient patterns
    keywords = []
    
    # Acronyms (2-10 uppercase letters, optionally with hyphens/numbers)
    try:
        acronyms = re.findall(r'\b[A-Z]{2,10}(?:-[A-Z0-9]+)?\b', text)
        keywords.extend(acronyms[:20])  # Limit to first 20
    except:
        pass
    
    # Version numbers
    try:
        versions = re.findall(r'\bv(?:ersion)?\s*\d+\.\d+(?:\.\d+)?\b', text, re.IGNORECASE)
        keywords.extend(versions[:5])
    except:
        pass
    
    return list(set(keywords))[:15]  # Return max 15 unique keywords

def preprocess_document(record: Dict[str, Any]) -> Dict[str, Any]:
    """
    Preprocess a single SDR record for optimal embedding
    
    Returns:
        Dictionary with processed text and metadata
    """
    key_data = record.get('key_data', {})
    metadata = record.get('metadata', {})
    
    # Build structured text for embedding with field labels and priority weighting
    text_parts = []
    keywords_collected = []
    
    # Process fields according to priority
    for field, (weight, label) in EMBEDDING_FIELDS_CONFIG.items():
        value = key_data.get(field) or metadata.get(field, "")
        
        if value and value != "":
            cleaned_value = clean_text(value)
            if cleaned_value:
                # Add field with label (repeat based on weight for emphasis)
                for _ in range(weight):
                    text_parts.append(f"{label}: {cleaned_value}")
                
                # Extract keywords from high-priority fields
                if weight >= 2:
                    keywords_collected.extend(extract_keywords(cleaned_value))
    
    # Add metadata fields (once each, without weighting)
    for field in METADATA_FIELDS:
        value = metadata.get(field, "")
        if value and value != "":
            cleaned_value = clean_text(value)
            if cleaned_value:
                text_parts.append(f"{field}: {cleaned_value}")
    
    # Add extracted keywords as a separate section for emphasis
    if keywords_collected:
        unique_keywords = list(set(keywords_collected))[:10]  # Top 10 unique keywords
        text_parts.append(f"Keywords: {' '.join(unique_keywords)}")
    
    # Combine all parts
    full_text = "\n".join(text_parts)
    
    # Truncate to model's max sequence length to prevent slowdowns
    # GTE-Large has 8192 token limit, ~4 chars per token = ~32k chars safe limit
    MAX_CHARS = 20000
    if len(full_text) > MAX_CHARS:
        full_text = full_text[:MAX_CHARS] + "... [truncated]"
    
    # Add instruction prefix for GTE model (improves query-document alignment)
    full_text_with_prefix = f"Represent this software defect report for retrieval: {full_text}"
    
    return {
        'text': full_text_with_prefix,
        'metadata': {
            'id': str(key_data.get('ID', 'unknown')),
            'title': clean_text(key_data.get('Title', '')),
            'work_item_type': key_data.get('Work Item Type', ''),
            'product': key_data.get('Product', ''),
            'product_category': key_data.get('Product Category', ''),
            'severity': metadata.get('Severity', ''),
            'state': metadata.get('State', ''),
            'source_sheet': metadata.get('source_sheet', ''),
            'product_version': metadata.get('Product Version', ''),
            'raw_text_length': len(full_text),
        }
    }

# ============================================================================
# EMBEDDING AND STORAGE FUNCTIONS
# ============================================================================

def load_and_preprocess_data(json_file: str) -> List[Dict[str, Any]]:
    """
    Load JSON data and preprocess all records
    """
    print(f"Loading data from {json_file}...", flush=True)
    with open(json_file, 'r', encoding='utf-8') as f:
        raw_data = json.load(f)
    
    print(f"Loaded {len(raw_data)} records", flush=True)
    print("Preprocessing records...", flush=True)
    
    processed_data = []
    total = len(raw_data)
    for idx, record in enumerate(raw_data, 1):
        if idx % 500 == 0 or idx == total:
            print(f"  → Processing record {idx}/{total} ({idx*100//total}%)", flush=True)
        processed = preprocess_document(record)
        processed_data.append(processed)
    
    print(f"✅ Preprocessing completed: {len(processed_data)} records processed\n", flush=True)
    return processed_data

def create_embeddings_batch(model: SentenceTransformer, texts: List[str], batch_num: int = 0, total_batches: int = 0) -> np.ndarray:
    """
    Create embeddings for a batch of texts
    """
    print(f"  → Embedding batch {batch_num}/{total_batches} ({len(texts)} documents)...", flush=True)
    
    try:
        # Explicitly disable gradient computation to avoid MPS memory issues
        with torch.no_grad():
            # GTE model works best with specific instructions
            # Note: We keep convert_to_numpy=True for compatibility with ChromaDB
            # The GPU acceleration happens during the encoding phase before conversion
            embeddings = model.encode(
                texts,
                batch_size=BATCH_SIZE,
                show_progress_bar=False,
                convert_to_numpy=True,
                normalize_embeddings=True  # Important for cosine similarity
                # device parameter is inherited from model initialization
            )
        
        print(f"  ✅ Batch {batch_num}/{total_batches} complete (shape: {embeddings.shape})", flush=True)
        return embeddings
    
    except Exception as e:
        print(f"  ❌ Error encoding batch {batch_num}: {e}", flush=True)
        # Try to recover with CPU fallback
        print(f"  ⚠️  Attempting CPU fallback for batch {batch_num}...", flush=True)
        try:
            embeddings = model.encode(
                texts,
                batch_size=BATCH_SIZE,
                show_progress_bar=False,
                convert_to_numpy=True,
                normalize_embeddings=True,
                device='cpu'  # Force CPU
            )
            print(f"  ✅ Batch {batch_num} completed on CPU", flush=True)
            return embeddings
        except Exception as e2:
            print(f"  ❌ CPU fallback also failed: {e2}", flush=True)
            raise

def initialize_chromadb(db_path: str, collection_name: str) -> chromadb.Collection:
    """
    Initialize ChromaDB client and collection
    """
    print(f"Initializing ChromaDB at {db_path}...")
    
    # Create persistent client
    client = chromadb.PersistentClient(
        path=db_path,
        settings=Settings(
            anonymized_telemetry=False,
            allow_reset=True
        )
    )
    
    # Delete existing collection if it exists
    try:
        client.delete_collection(name=collection_name)
        print(f"Deleted existing collection: {collection_name}")
    except Exception:
        pass
    
    # Create new collection with cosine similarity
    collection = client.create_collection(
        name=collection_name,
        metadata={
            "hnsw:space": "cosine",  # Use cosine similarity
            "description": "SDR embeddings"
        }
    )
    
    print(f"Created collection: {collection_name}")
    return collection

def store_in_chromadb(
    collection: chromadb.Collection,
    processed_data: List[Dict[str, Any]],
    model: SentenceTransformer
):
    """
    Generate embeddings and store in ChromaDB in batches
    """
    import gc
    
    total_records = len(processed_data)
    print(f"\nGenerating embeddings and storing {total_records} records in ChromaDB...", flush=True)
    print(f"Batch size: {BATCH_SIZE}", flush=True)
    print("This may take 5-10 minutes depending on your hardware...", flush=True)
    
    # Process in batches
    num_batches = (total_records + BATCH_SIZE - 1) // BATCH_SIZE
    print(f"Total batches to process: {num_batches}", flush=True)
    print("", flush=True)
    
    # We'll accumulate small batches and write to ChromaDB in larger chunks
    WRITE_BATCH_MULTIPLIER = 8  # number of small batches to accumulate before a write (8 * BATCH_SIZE docs)
    write_buffer_embeddings = []
    write_buffer_texts = []
    write_buffer_metadatas = []
    write_buffer_ids = []
    write_count = 0
    total_store_time = 0.0

    for i in range(0, total_records, BATCH_SIZE):
        batch_num = (i // BATCH_SIZE) + 1
        batch = processed_data[i:i + BATCH_SIZE]

        print(f"[Batch {batch_num}/{num_batches}] Starting...", flush=True)

        # Extract texts and metadata
        texts = [record['text'] for record in batch]
        metadatas = [record['metadata'] for record in batch]
        ids = [record['metadata']['id'] for record in batch]

        print(f"  → Extracted {len(texts)} texts, preparing embeddings...", flush=True)

        # Generate embeddings
        embeddings = create_embeddings_batch(model, texts, batch_num, num_batches)

        # Append to write buffers
        write_buffer_embeddings.extend(embeddings.tolist())
        write_buffer_texts.extend(texts)
        write_buffer_metadatas.extend(metadatas)
        write_buffer_ids.extend(ids)

        # Every WRITE_BATCH_MULTIPLIER small batches (or at end), flush to ChromaDB
        if (batch_num % WRITE_BATCH_MULTIPLIER == 0) or (i + BATCH_SIZE >= total_records):
            write_count += 1
            num_docs_to_write = len(write_buffer_ids)
            print(f"  → Flushing {num_docs_to_write} documents to ChromaDB (write #{write_count})...", flush=True)
            t0 = time.time()
            collection.add(
                embeddings=write_buffer_embeddings,
                documents=write_buffer_texts,
                metadatas=write_buffer_metadatas,
                ids=write_buffer_ids
            )
            t1 = time.time()
            store_time = t1 - t0
            total_store_time += store_time
            print(f"  ✅ Flushed {num_docs_to_write} docs in {store_time:.3f}s (total store time: {total_store_time:.3f}s)", flush=True)

            # Clear buffers
            write_buffer_embeddings = []
            write_buffer_texts = []
            write_buffer_metadatas = []
            write_buffer_ids = []

            # Clear GPU memory occasionally
            if batch_num % (WRITE_BATCH_MULTIPLIER * 5) == 0 and str(model.device).startswith('mps'):
                gc.collect()
                try:
                    torch.mps.empty_cache()
                except Exception:
                    pass

        print(f"  ✅ Batch {batch_num}/{num_batches} processed", flush=True)
        print(f"  📊 Progress: {min(i + BATCH_SIZE, total_records)}/{total_records} documents ({100 * min(i + BATCH_SIZE, total_records) / total_records:.1f}%)", flush=True)
        print("", flush=True)
    
    print(f"✅ Successfully stored {total_records} records in ChromaDB", flush=True)

def verify_storage(collection: chromadb.Collection):
    """
    Verify data was stored correctly
    """
    print("\n" + "="*80)
    print("VERIFICATION")
    print("="*80)
    
    count = collection.count()
    print(f"Total documents in collection: {count}")
    
    # Get a sample document
    sample = collection.get(limit=1, include=['embeddings', 'metadatas', 'documents'])
    
    if sample['ids']:
        print(f"\nSample Document ID: {sample['ids'][0]}")
        print(f"Embedding dimension: {len(sample['embeddings'][0])}")
        print(f"Metadata: {sample['metadatas'][0]}")
        print(f"Document preview: {sample['documents'][0][:200]}...")
    
    print("="*80)

# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main(model_path: str = None, chromadb_path: str = None, collection_name: str = None, model_name: str = "GTE-Large"):
    """
    Main execution function
    
    Args:
        model_path: Path to the embedding model (overrides default)
        chromadb_path: Path to ChromaDB storage (overrides default)
        collection_name: Name of ChromaDB collection (overrides default)
        model_name: Display name of the model
    """
    # Use provided paths or defaults
    model_path = model_path or MODEL_PATH
    chromadb_path = chromadb_path or CHROMADB_PATH
    collection_name = collection_name or COLLECTION_NAME
    
    start_time = time.time()
    
    # Force PyTorch to use MPS if available (environment variable)
    import os
    import gc
    os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] = '1'
    
    print("="*80)
    print("SDR EMBEDDING GENERATION AND CHROMADB STORAGE")
    print("="*80)
    print(f"Model: {model_name}")
    print(f"Model Path: {model_path}")
    print(f"Input: {INPUT_JSON_FILE}")
    print(f"Output: ChromaDB at {chromadb_path}")
    print(f"Collection: {collection_name}")
    print("="*80 + "\n")
    
    # Step 1: Load the embedding model
    print("Step 1: Loading embedding model...")
    step_start = time.time()
    
    # Use MPS with smaller batches and memory management
    if torch.backends.mps.is_available():
        device = 'mps'
        print(f"✅ Using Apple Silicon GPU (MPS) with stability fixes")
        print(f"   - Reduced batch size to {BATCH_SIZE}")
        print(f"   - Added memory management")
        print(f"   - CPU fallback on errors")
    else:
        device = 'cpu'
        print(f"⚠️  Using CPU (no GPU available)")
    
    model = SentenceTransformer(model_path, trust_remote_code=True, device=device)
    
    # Verify the model is on the correct device
    print(f"✅ Model device verified: {model.device}")
    
    step_time = time.time() - step_start
    print(f"✅ Model loaded successfully (took {step_time:.2f} seconds)")
    print(f"   Device: {device}")
    print(f"   Model dimension: {model.get_sentence_embedding_dimension()}")
    print(f"   Max sequence length: {model.max_seq_length}\n")
    
    # Step 2: Load and preprocess data
    print("Step 2: Loading and preprocessing data...")
    step_start = time.time()
    processed_data = load_and_preprocess_data(INPUT_JSON_FILE)
    step_time = time.time() - step_start
    print(f"✅ Preprocessed {len(processed_data)} records (took {step_time:.2f} seconds)\n")
    
    # Show sample processed text
    if processed_data:
        print("Sample preprocessed text (first document):")
        print("-" * 80)
        sample_text = processed_data[0]['text']
        # Show first 600 characters
        print(sample_text[:600] + "..." if len(sample_text) > 600 else sample_text)
        print("-" * 80)
        print(f"Total text length: {len(sample_text)} characters")
        print(f"Sample metadata: {processed_data[0]['metadata']}")
        print("-" * 80 + "\n")
        print("", flush=True)
    
    # Step 3: Initialize ChromaDB
    print("Step 3: Initializing ChromaDB...")
    step_start = time.time()
    collection = initialize_chromadb(chromadb_path, collection_name)
    step_time = time.time() - step_start
    print(f"✅ ChromaDB initialized (took {step_time:.2f} seconds)\n")
    
    # Step 4: Generate embeddings and store
    print("Step 4: Generating embeddings and storing in ChromaDB...")
    step_start = time.time()
    store_in_chromadb(collection, processed_data, model)
    step_time = time.time() - step_start
    print(f"✅ Embeddings generated and stored (took {step_time:.2f} seconds)\n")
    
    # Step 5: Verify storage
    print("Step 5: Verifying storage...")
    verify_storage(collection)
    
    print("\n" + "="*80)
    print("✅ PROCESS COMPLETED SUCCESSFULLY")
    print("="*80)
    print(f"\nChromaDB collection '{collection_name}' is ready for retrieval!")
    print(f"Location: {chromadb_path}")
    print(f"Total documents: {collection.count()}")
    
    # Save configuration for reference
    config = {
        'model_path': model_path,
        'model_name': model_name,
        'embedding_dimension': model.get_sentence_embedding_dimension(),
        'total_documents': collection.count(),
        'collection_name': collection_name,
        'embedding_fields': list(EMBEDDING_FIELDS_CONFIG.keys()),
        'metadata_fields': METADATA_FIELDS,
        'batch_size': BATCH_SIZE
    }
    
    with open('chromadb_config.json', 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2)
    
    print(f"Configuration saved to: chromadb_config.json")

if __name__ == "__main__":
    # Parse command-line arguments
    if len(sys.argv) > 1:
        if len(sys.argv) < 5:
            print("Usage: python create_chromadb_embeddings.py <model_path> <chromadb_path> <collection_name> <model_name>")
            print("Example: python create_chromadb_embeddings.py /path/to/model ./chromadb_storage sdr_collection GTE-Large")
            sys.exit(1)
        
        model_path = sys.argv[1]
        chromadb_path = sys.argv[2]
        collection_name = sys.argv[3]
        model_name = sys.argv[4] if len(sys.argv) > 4 else "Custom Model"
        
        main(model_path, chromadb_path, collection_name, model_name)
    else:
        # Use defaults
        main()
