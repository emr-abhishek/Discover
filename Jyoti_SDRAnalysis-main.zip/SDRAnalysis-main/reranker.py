"""
Reranking Module for Gemma Pipeline
Implements cross-encoder reranking for improved retrieval accuracy
"""

import numpy as np
from typing import List, Dict, Any, Tuple
from sentence_transformers import CrossEncoder

from .config import GemmaConfig


class GemmaReranker:
    """Cross-encoder reranker for two-stage retrieval"""
    
    # Default cross-encoder model
    DEFAULT_CROSS_ENCODER = "cross-encoder/ms-marco-MiniLM-L-6-v2"
    
    def __init__(self, config: GemmaConfig = None, cross_encoder_model: str = None):
        """
        Initialize reranker
        
        Args:
            config: Pipeline configuration
            cross_encoder_model: Cross-encoder model name/path
        """
        self.config = config or GemmaConfig()
        self.cross_encoder_model = cross_encoder_model or self.DEFAULT_CROSS_ENCODER
        self.cross_encoder = None
    
    def load_cross_encoder(self):
        """Load cross-encoder model"""
        if self.cross_encoder:
            return  # Already loaded
        
        print(f"Loading cross-encoder: {self.cross_encoder_model}")
        
        # Use CPU for cross-encoder to avoid device conflicts
        self.cross_encoder = CrossEncoder(self.cross_encoder_model, device='cpu')
        
        print(f"✅ Cross-encoder loaded\n")
    
    def rerank(
        self, 
        query: str, 
        candidate_ids: List[str],
        candidate_texts: List[str],
        top_k: int = 10
    ) -> Tuple[List[str], List[float]]:
        """
        Rerank candidates using cross-encoder
        
        Args:
            query: Query text
            candidate_ids: List of candidate document IDs
            candidate_texts: List of candidate document texts
            top_k: Number of top results to return
        
        Returns:
            Tuple of (reranked_ids, reranked_scores)
        """
        if not self.cross_encoder:
            self.load_cross_encoder()
        
        # Prepare query-document pairs
        pairs = [[query, text] for text in candidate_texts]
        
        # Score with cross-encoder (batch processing)
        cross_scores = self.cross_encoder.predict(pairs, batch_size=32, show_progress_bar=False)
        
        # Sort by cross-encoder scores (higher is better)
        scored_results = list(zip(candidate_ids, cross_scores))
        scored_results.sort(key=lambda x: x[1], reverse=True)
        
        # Get top-k after reranking
        top_results = scored_results[:top_k]
        
        reranked_ids = [x[0] for x in top_results]
        reranked_scores = [float(x[1]) for x in top_results]
        
        return reranked_ids, reranked_scores
    
    def retrieve_and_rerank(
        self,
        retriever,
        query: str,
        retrieval_k: int = 30,
        rerank_k: int = 10
    ) -> Dict[str, Any]:
        """
        Two-stage retrieval: semantic search + cross-encoder reranking
        
        Args:
            retriever: GemmaRetriever instance
            query: Query text
            retrieval_k: Number of candidates to retrieve initially
            rerank_k: Number of final results after reranking
        
        Returns:
            Dictionary with reranked results
        """
        # Stage 1: Retrieve candidates with semantic search
        results = retriever.query(query, n_results=retrieval_k)
        
        if not results or not results['ids'] or len(results['ids']) == 0:
            return {
                'ids': [[]],
                'scores': [[]],
                'original_ids': [[]],
                'documents': [[]]
            }
        
        candidate_ids = results['ids'][0]
        candidate_docs = results.get('documents', [[]])[0]
        
        # Stage 2: Rerank with cross-encoder
        reranked_ids, reranked_scores = self.rerank(
            query, 
            candidate_ids, 
            candidate_docs,
            top_k=rerank_k
        )
        
        return {
            'ids': [reranked_ids],
            'scores': [reranked_scores],
            'original_ids': [candidate_ids],
            'metadatas': results.get('metadatas', [[]]),
            'documents': results.get('documents', [[]])
        }
