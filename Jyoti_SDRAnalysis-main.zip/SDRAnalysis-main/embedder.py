"""
Embedding Generation Module for Gemma Pipeline
Handles embedding generation and ChromaDB storage
"""

import torch
import numpy as np
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
from typing import List, Dict, Any
from pathlib import Path
import gc

from .config import GemmaConfig


class GemmaEmbedder:
    """Handle embedding generation using Gemma model"""
    
    def __init__(self, config: GemmaConfig = None):
        """Initialize embedder with Gemma model"""
        self.config = config or GemmaConfig()
        self.model = None
        self.collection = None
    
    def load_model(self):
        """Load Gemma embedding model"""
        print(f"Loading Gemma model from: {self.config.MODEL_PATH}")
        
        if not Path(self.config.MODEL_PATH).exists():
            raise FileNotFoundError(f"Model not found at: {self.config.MODEL_PATH}")
        
        # Detect device
        if torch.cuda.is_available():
            device = 'cuda'
            print("  Using CUDA GPU")
        elif torch.backends.mps.is_available():
            device = 'mps'
            print("  Using Apple Silicon GPU (MPS)")
        else:
            device = 'cpu'
            print("  Using CPU")
        
        self.model = SentenceTransformer(
            self.config.MODEL_PATH,
            device=device,
            trust_remote_code=True
        )
        
        # Auto-detect embedding dimension
        self.config.EMBEDDING_DIMENSION = self.model.get_sentence_embedding_dimension()
        
        print(f"✅ Model loaded successfully")
        print(f"   Embedding dimension: {self.config.EMBEDDING_DIMENSION}")
        print(f"   Device: {device}\n")
    
    def initialize_chromadb(self) -> chromadb.Collection:
        """Initialize ChromaDB client and collection"""
        print(f"Initializing ChromaDB at {self.config.CHROMADB_PATH}...")
        
        # Create persistent client
        client = chromadb.PersistentClient(
            path=self.config.CHROMADB_PATH,
            settings=Settings(
                anonymized_telemetry=False,
                allow_reset=True
            )
        )
        
        # Delete existing collection if it exists
        try:
            client.delete_collection(name=self.config.COLLECTION_NAME)
            print(f"  Deleted existing collection: {self.config.COLLECTION_NAME}")
        except Exception:
            pass
        
        # Create new collection with cosine similarity
        self.collection = client.create_collection(
            name=self.config.COLLECTION_NAME,
            metadata={
                "hnsw:space": "cosine",
                "description": f"SDR embeddings using {self.config.MODEL_NAME}"
            }
        )
        
        print(f"✅ Created collection: {self.config.COLLECTION_NAME}\n")
        return self.collection
    
    def create_embeddings_batch(self, texts: List[str], batch_num: int = 0, total_batches: int = 0) -> np.ndarray:
        """
        Create embeddings for a batch of texts
        
        Args:
            texts: List of text strings
            batch_num: Current batch number
            total_batches: Total number of batches
        
        Returns:
            Numpy array of embeddings
        """
        print(f"  → Embedding batch {batch_num}/{total_batches} ({len(texts)} documents)...")
        
        try:
            with torch.no_grad():
                embeddings = self.model.encode(
                    texts,
                    batch_size=self.config.BATCH_SIZE,
                    show_progress_bar=False,
                    convert_to_numpy=True,
                    normalize_embeddings=True
                )
            
            print(f"  ✅ Batch {batch_num}/{total_batches} complete (shape: {embeddings.shape})")
            return embeddings
        
        except Exception as e:
            print(f"  ❌ Error encoding batch {batch_num}: {e}")
            # Try CPU fallback
            print(f"  ⚠️  Attempting CPU fallback for batch {batch_num}...")
            try:
                embeddings = self.model.encode(
                    texts,
                    batch_size=self.config.BATCH_SIZE,
                    show_progress_bar=False,
                    convert_to_numpy=True,
                    normalize_embeddings=True,
                    device='cpu'
                )
                print(f"  ✅ Batch {batch_num} completed on CPU")
                return embeddings
            except Exception as e2:
                print(f"  ❌ CPU fallback also failed: {e2}")
                raise
    
    def store_in_chromadb(self, processed_data: List[Dict[str, Any]]):
        """
        Generate embeddings and store in ChromaDB in batches
        
        Args:
            processed_data: List of preprocessed documents
        """
        if not self.model:
            self.load_model()
        
        if not self.collection:
            self.initialize_chromadb()
        
        print(f"Generating embeddings for {len(processed_data)} documents...")
        print(f"Batch size: {self.config.BATCH_SIZE}\n")
        
        # Calculate number of batches
        total_docs = len(processed_data)
        batch_size = 100  # Store in batches of 100
        total_batches = (total_docs + batch_size - 1) // batch_size
        
        for batch_idx in range(total_batches):
            start_idx = batch_idx * batch_size
            end_idx = min(start_idx + batch_size, total_docs)
            batch_data = processed_data[start_idx:end_idx]
            
            print(f"\n=== Batch {batch_idx + 1}/{total_batches} (documents {start_idx + 1}-{end_idx}) ===")
            
            # Extract texts for embedding
            texts = [doc['text'] for doc in batch_data]
            
            # Generate embeddings
            embeddings = self.create_embeddings_batch(
                texts,
                batch_num=batch_idx + 1,
                total_batches=total_batches
            )
            
            # Prepare data for ChromaDB
            ids = [doc['metadata']['id'] for doc in batch_data]
            metadatas = [doc['metadata'] for doc in batch_data]
            documents = [doc['text'][:500] + "..." if len(doc['text']) > 500 else doc['text'] 
                        for doc in batch_data]  # Store truncated text for debugging
            
            # Add to ChromaDB
            print(f"  → Storing batch {batch_idx + 1} in ChromaDB...")
            self.collection.add(
                embeddings=embeddings.tolist(),
                documents=documents,
                metadatas=metadatas,
                ids=ids
            )
            print(f"  ✅ Batch {batch_idx + 1} stored successfully")
            
            # Memory cleanup
            del embeddings
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        
        print(f"\n{'='*60}")
        print(f"✅ ALL EMBEDDINGS STORED SUCCESSFULLY")
        print(f"   Total documents: {self.collection.count()}")
        print(f"   Collection: {self.config.COLLECTION_NAME}")
        print(f"   Storage path: {self.config.CHROMADB_PATH}")
        print(f"{'='*60}\n")
        
        # Save configuration
        import json
        config_data = {
            'model_name': self.config.MODEL_NAME,
            'model_path': self.config.MODEL_PATH,
            'embedding_dimension': self.config.EMBEDDING_DIMENSION,
            'collection_name': self.config.COLLECTION_NAME,
            'chromadb_path': self.config.CHROMADB_PATH,
            'total_documents': self.collection.count(),
            'batch_size': self.config.BATCH_SIZE,
        }
        
        with open(self.config.CONFIG_FILE, 'w') as f:
            json.dump(config_data, f, indent=2)
        
        print(f"✅ Configuration saved to {self.config.CONFIG_FILE}\n")
