#!/usr/bin/env python3
"""
Gemma Pipeline Runner
Main entry point for the Gemma-based SDR retrieval pipeline
"""

import sys
import argparse
from pathlib import Path

# Add the parent directory to the path
sys.path.insert(0, str(Path(__file__).parent))

from gemma_pipeline.pipeline import GemmaPipeline
from gemma_pipeline.config import GemmaConfig


def main():
    """Main execution function"""
    parser = argparse.ArgumentParser(
        description='Gemma-based SDR Retrieval Pipeline',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run full pipeline with default settings
  python run_gemma_pipeline.py --full
  
  # Run specific steps
  python run_gemma_pipeline.py --step0  # Generate ground truth
  python run_gemma_pipeline.py --step1  # Convert Excel to JSON
  python run_gemma_pipeline.py --step2  # Create embeddings
  python run_gemma_pipeline.py --step3  # Evaluate retrieval (auto-generates ground truth)
  
  # Evaluate with reranking
  python run_gemma_pipeline.py --step3 --rerank
  
  # Use custom Excel file
  python run_gemma_pipeline.py --full --excel mydata.xlsx
  
  # Generate ground truth to custom file
  python run_gemma_pipeline.py --step0 --gt-output my_groundtruth.json
  
  # Evaluate with custom ground truth file
  python run_gemma_pipeline.py --step3 --ground-truth my_groundtruth.json
  
  # Interactive query mode
  python run_gemma_pipeline.py --query
  
  # Check prerequisites only
  python run_gemma_pipeline.py --check
        """
    )
    
    # Mode selection
    parser.add_argument('--full', action='store_true',
                        help='Run the complete pipeline (Steps 1-3)')
    parser.add_argument('--step0', action='store_true',
                        help='Step 0: Generate ground truth for evaluation')
    parser.add_argument('--step1', action='store_true',
                        help='Step 1: Convert Excel to JSON')
    parser.add_argument('--step2', action='store_true',
                        help='Step 2: Create embeddings and ChromaDB')
    parser.add_argument('--step3', action='store_true',
                        help='Step 3: Evaluate retrieval performance (auto-generates ground truth if missing)')
    parser.add_argument('--query', action='store_true',
                        help='Interactive query mode')
    parser.add_argument('--check', action='store_true',
                        help='Check prerequisites only')
    
    # Reranking options
    parser.add_argument('--rerank', action='store_true',
                        help='Enable cross-encoder reranking (for step3)')
    parser.add_argument('--retrieval-k', type=int, default=30,
                        help='Number of candidates to retrieve for reranking (default: 30)')
    
    # File options
    parser.add_argument('--excel', type=str, default=None,
                        help='Path to Excel file (default: sdr.xlsx)')
    parser.add_argument('--ground-truth', type=str, default=None,
                        help='Path to ground truth file for evaluation (default: SDR_Groundtruth_generated.json)')
    parser.add_argument('--gt-output', type=str, default=None,
                        help='Output path for generated ground truth file (default: SDR_Groundtruth_generated.json)')
    parser.add_argument('--skip-conversion', action='store_true',
                        help='Skip Excel to JSON conversion if JSON exists')
    parser.add_argument('--num-queries', type=int, default=50,
                        help='Number of ground truth queries to generate (default: 50)')
    
    args = parser.parse_args()
    
    # If no arguments, show help
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(0)
    
    # Initialize pipeline
    print("\n" + "="*80)
    print("GEMMA-BASED SDR RETRIEVAL PIPELINE")
    print("="*80 + "\n")
    
    pipeline = GemmaPipeline()
    
    # Check prerequisites
    if args.check:
        pipeline.check_prerequisites()
        return
    
    # Run full pipeline
    if args.full:
        success = pipeline.run_full_pipeline(
            excel_file=args.excel,
            skip_conversion=args.skip_conversion
        )
        sys.exit(0 if success else 1)
    
    # Run individual steps
    if args.step0:
        success = pipeline.step0_generate_ground_truth(
            num_queries=args.num_queries,
            output_file=args.gt_output
        )
        sys.exit(0 if success else 1)
    
    if args.step1:
        success = pipeline.step1_convert_excel_to_json(excel_file=args.excel)
        sys.exit(0 if success else 1)
    
    if args.step2:
        success = pipeline.step2_create_embeddings()
        sys.exit(0 if success else 1)
    
    if args.step3:
        success = pipeline.step3_evaluate(
            ground_truth_file=args.ground_truth, 
            auto_generate=True,
            use_reranking=args.rerank,
            retrieval_k=args.retrieval_k
        )
        sys.exit(0 if success else 1)
    
    # Interactive query mode
    if args.query:
        pipeline.query_interactive()
        return
    
    # If no valid mode selected, show help
    print("Error: Please specify a mode (--full, --step1, --step2, --step3, --query, or --check)")
    parser.print_help()
    sys.exit(1)


if __name__ == "__main__":
    main()
