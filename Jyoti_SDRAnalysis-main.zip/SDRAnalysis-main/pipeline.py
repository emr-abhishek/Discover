"""
Main Pipeline Orchestrator for Gemma Pipeline
Coordinates all components for end-to-end execution
"""

from pathlib import Path
from typing import Optional, Callable
import logging
import sys

from .config import GemmaConfig
from .data_processor import DataProcessor
from .embedder import GemmaEmbedder
from .retriever import GemmaRetriever
from .evaluator import GemmaEvaluator


class GemmaPipeline:
    """Main pipeline orchestrator"""
    
    def __init__(self, config: GemmaConfig = None, log_callback: Optional[Callable] = None):
        """
        Initialize pipeline
        
        Args:
            config: Pipeline configuration
            log_callback: Optional callback function for logging (for UI integration)
        """
        self.config = config or GemmaConfig()
        self.log_callback = log_callback
        
        # Initialize components
        self.data_processor = DataProcessor(self.config)
        self.embedder = GemmaEmbedder(self.config)
        self.retriever = GemmaRetriever(self.config)
        self.evaluator = GemmaEvaluator(self.config, use_reranking=False)
        self.evaluator_reranked = None  # Lazy initialization
        
        self.setup_logging()
    
    def setup_logging(self):
        """Setup logging configuration"""
        log_format = '%(asctime)s - %(levelname)s - %(message)s'
        logging.basicConfig(
            level=logging.INFO,
            format=log_format,
            handlers=[
                logging.FileHandler(self.config.LOG_FILE),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)
    
    def log(self, message: str, level: str = "INFO"):
        """
        Log a message
        
        Args:
            message: The message to log
            level: Log level (INFO, WARNING, ERROR, SUCCESS)
        """
        if level == "ERROR":
            self.logger.error(message)
        elif level == "WARNING":
            self.logger.warning(message)
        else:
            self.logger.info(message)
        
        if self.log_callback:
            self.log_callback(message, level)
    
    def check_prerequisites(self) -> dict:
        """
        Check if all prerequisites are met
        
        Returns:
            Dictionary with status of each prerequisite
        """
        self.log("=" * 80)
        self.log("CHECKING PREREQUISITES")
        self.log("=" * 80)
        
        status = self.config.validate_paths()
        
        # Check model
        if status['model_path']:
            self.log(f"✅ Gemma model found: {self.config.MODEL_PATH}", "SUCCESS")
        else:
            self.log(f"❌ Gemma model not found: {self.config.MODEL_PATH}", "ERROR")
        
        # Check Excel file
        if status['excel_file']:
            self.log(f"✅ Excel file found: {self.config.EXCEL_FILE}", "SUCCESS")
        else:
            self.log(f"❌ Excel file not found: {self.config.EXCEL_FILE}", "ERROR")
        
        # Check JSON file (optional)
        if status['json_file']:
            self.log(f"✅ JSON file found: {self.config.JSON_FILE}", "SUCCESS")
        else:
            self.log(f"⚠️  JSON file not found (will be created in Step 1)", "WARNING")
        
        # Check ground truth (optional)
        if status['ground_truth']:
            self.log(f"✅ Ground truth file found: {self.config.GROUND_TRUTH_FILE}", "SUCCESS")
        else:
            self.log(f"⚠️  Ground truth file not found (optional for evaluation)", "WARNING")
        
        # Check packages
        try:
            import chromadb
            import sentence_transformers
            import pandas
            import numpy
            import torch
            self.log("✅ All required packages installed", "SUCCESS")
            status['packages'] = True
        except ImportError as e:
            self.log(f"❌ Missing package: {e}", "ERROR")
            status['packages'] = False
        
        self.log("")
        return status
    
    def step1_convert_excel_to_json(self, excel_file: str = None) -> bool:
        """
        Step 1: Convert Excel to JSON
        
        Args:
            excel_file: Optional Excel file path
        
        Returns:
            True if successful, False otherwise
        """
        try:
            self.log("=" * 80)
            self.log("STEP 1: CONVERTING EXCEL TO JSON")
            self.log("=" * 80)
            
            excel_file = excel_file or self.config.EXCEL_FILE
            
            if not Path(excel_file).exists():
                self.log(f"❌ Excel file not found: {excel_file}", "ERROR")
                return False
            
            num_records = self.data_processor.excel_to_json(excel_file)
            
            self.log(f"✅ Successfully converted {num_records} records to JSON", "SUCCESS")
            self.log("")
            return True
        
        except Exception as e:
            self.log(f"❌ Error in Step 1: {str(e)}", "ERROR")
            return False
    
    def step2_create_embeddings(self) -> bool:
        """
        Step 2: Create embeddings and store in ChromaDB
        
        Returns:
            True if successful, False otherwise
        """
        try:
            self.log("=" * 80)
            self.log("STEP 2: CREATING EMBEDDINGS")
            self.log("=" * 80)
            
            if not Path(self.config.JSON_FILE).exists():
                self.log(f"❌ JSON file not found. Please run Step 1 first.", "ERROR")
                return False
            
            # Load and preprocess data
            processed_data = self.data_processor.load_and_preprocess_data()
            
            # Generate embeddings and store in ChromaDB
            self.embedder.store_in_chromadb(processed_data)
            
            self.log(f"✅ Successfully created embeddings for {len(processed_data)} documents", "SUCCESS")
            self.log("")
            return True
        
        except Exception as e:
            self.log(f"❌ Error in Step 2: {str(e)}", "ERROR")
            import traceback
            self.log(traceback.format_exc(), "ERROR")
            return False
    
    def step0_generate_ground_truth(self, num_queries: int = 50, output_file: str = None) -> bool:
        """
        Step 0: Generate ground truth for evaluation
        
        Args:
            num_queries: Number of test queries to generate
            output_file: Custom output file path (optional)
        
        Returns:
            True if successful, False otherwise
        """
        try:
            output_file = output_file or self.config.GROUND_TRUTH_FILE
            
            self.log("=" * 80)
            self.log("STEP 0: GENERATING GROUND TRUTH")
            self.log("=" * 80)
            self.log(f"Output file: {output_file}")
            
            # Check prerequisites
            if not Path(self.config.JSON_FILE).exists():
                self.log(f"❌ JSON file not found: {self.config.JSON_FILE}", "ERROR")
                self.log("   Please run Step 1 first.", "ERROR")
                return False
            
            if not Path(self.config.CHROMADB_PATH).exists():
                self.log(f"❌ ChromaDB not found: {self.config.CHROMADB_PATH}", "ERROR")
                self.log("   Please run Step 2 first.", "ERROR")
                return False
            
            # Import the ground truth generator
            import subprocess
            import sys
            
            self.log(f"Generating {num_queries} test queries...")
            
            # Run ground truth generation
            cmd = [sys.executable, 'create_ground_truth.py', str(num_queries)]
            if output_file != self.config.GROUND_TRUTH_FILE:
                cmd.extend(['--output', output_file])
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=False
            )
            
            # Log output
            if result.stdout:
                for line in result.stdout.strip().split('\n'):
                    self.log(line)
            
            if result.returncode != 0:
                if result.stderr:
                    self.log(result.stderr, "ERROR")
                raise Exception(f"Ground truth generation failed with return code {result.returncode}")
            
            # Verify output
            if Path(output_file).exists():
                import json
                with open(output_file, 'r') as f:
                    data = json.load(f)
                self.log(f"✅ Ground truth created successfully with {len(data)} test queries", "SUCCESS")
                self.log(f"   Saved to: {output_file}", "SUCCESS")
                self.log("")
                return True
            else:
                self.log(f"❌ Ground truth file was not created: {output_file}", "ERROR")
                return False
        
        except Exception as e:
            self.log(f"❌ Error in Step 0: {str(e)}", "ERROR")
            import traceback
            self.log(traceback.format_exc(), "ERROR")
            return False
    
    def step3_evaluate(self, ground_truth_file: str = None, auto_generate: bool = True, use_reranking: bool = False, retrieval_k: int = 30) -> bool:
        """
        Step 3: Evaluate retrieval performance
        
        Args:
            ground_truth_file: Optional ground truth file path
            auto_generate: If True, automatically generate ground truth if missing
            use_reranking: Enable cross-encoder reranking
            retrieval_k: Number of candidates for reranking (default: 30)
        
        Returns:
            True if successful, False otherwise
        """
        try:
            mode_str = "with Reranking" if use_reranking else "Standard"
            self.log("=" * 80)
            self.log(f"STEP 3: EVALUATING RETRIEVAL PERFORMANCE ({mode_str})")
            self.log("=" * 80)
            
            ground_truth_file = ground_truth_file or self.config.GROUND_TRUTH_FILE
            
            # Auto-generate ground truth if missing
            if not Path(ground_truth_file).exists():
                if auto_generate:
                    self.log(f"⚠️  Ground truth file not found: {ground_truth_file}", "WARNING")
                    self.log("   Generating ground truth automatically...", "WARNING")
                    if not self.step0_generate_ground_truth():
                        return False
                else:
                    self.log(f"❌ Ground truth file not found: {ground_truth_file}", "ERROR")
                    self.log("   Run with step0 first or enable auto_generate.", "ERROR")
                    return False
            
            if not Path(self.config.CHROMADB_PATH).exists():
                self.log(f"❌ ChromaDB not found. Please run Step 2 first.", "ERROR")
                return False
            
            # Use appropriate evaluator
            if use_reranking:
                if not self.evaluator_reranked:
                    from .evaluator import GemmaEvaluator
                    self.evaluator_reranked = GemmaEvaluator(self.config, use_reranking=True)
                evaluator = self.evaluator_reranked
                output_file = self.config.EVALUATION_RESULTS.replace('.json', '_reranked.json')
            else:
                evaluator = self.evaluator
                output_file = self.config.EVALUATION_RESULTS
            
            # Run evaluation
            results = evaluator.evaluate_ground_truth(ground_truth_file, retrieval_k=retrieval_k)
            
            # Save results
            evaluator.save_results(results, output_file)
            
            # Print summary
            evaluator.print_summary(results)
            
            self.log(f"✅ Evaluation complete", "SUCCESS")
            self.log("")
            return True
        
        except Exception as e:
            self.log(f"❌ Error in Step 3: {str(e)}", "ERROR")
            import traceback
            self.log(traceback.format_exc(), "ERROR")
            return False
    
    def run_full_pipeline(self, excel_file: str = None, skip_conversion: bool = False, skip_evaluation: bool = False) -> bool:
        """
        Run the complete pipeline
        
        Args:
            excel_file: Optional Excel file path
            skip_conversion: Skip Excel to JSON conversion if JSON already exists
            skip_evaluation: Skip evaluation step
        
        Returns:
            True if successful, False otherwise
        """
        self.log("\n" + "="*80)
        self.log("STARTING GEMMA PIPELINE")
        self.log("="*80 + "\n")
        
        # Ensure directories exist
        self.config.ensure_directories()
        
        # Check prerequisites
        prereqs = self.check_prerequisites()
        if not all([prereqs.get('model_path'), prereqs.get('packages')]):
            self.log("❌ Prerequisites not met. Cannot continue.", "ERROR")
            return False
        
        # Step 1: Convert Excel to JSON
        if not skip_conversion or not Path(self.config.JSON_FILE).exists():
            if not self.step1_convert_excel_to_json(excel_file):
                return False
        else:
            self.log("⏭️  Skipping Step 1 (JSON file already exists)")
        
        # Step 2: Create embeddings
        if not self.step2_create_embeddings():
            return False
        
        # Step 3: Evaluate (auto-generates ground truth if needed)
        if not skip_evaluation:
            if not self.step3_evaluate(auto_generate=True):
                self.log("⚠️  Evaluation failed, but embeddings were created successfully", "WARNING")
        else:
            self.log("⏭️  Skipping evaluation (disabled)")
        
        self.log("\n" + "="*80)
        self.log("✅ GEMMA PIPELINE COMPLETED SUCCESSFULLY")
        self.log("="*80 + "\n")
        
        return True
    
    def query_interactive(self):
        """Interactive query mode"""
        self.log("=" * 80)
        self.log("INTERACTIVE QUERY MODE")
        self.log("=" * 80)
        self.log("Enter queries to search the SDR database")
        self.log("Type 'exit' or 'quit' to stop\n")
        
        while True:
            try:
                query = input("\nEnter query: ").strip()
                
                if query.lower() in ['exit', 'quit', 'q']:
                    self.log("Exiting interactive mode...")
                    break
                
                if not query:
                    continue
                
                # Query the system
                results = self.retriever.query(query, n_results=5)
                
                if results and results['ids'] and len(results['ids']) > 0:
                    print(f"\n{'='*80}")
                    print(f"Top 5 Results:")
                    print(f"{'='*80}")
                    
                    for i, (doc_id, distance, metadata) in enumerate(
                        zip(results['ids'][0], results['distances'][0], results['metadatas'][0]),
                        1
                    ):
                        print(f"\n{i}. ID: {doc_id}")
                        print(f"   Distance: {distance:.4f}")
                        print(f"   Title: {metadata.get('title', 'N/A')}")
                        print(f"   Product: {metadata.get('product', 'N/A')}")
                        print(f"   Category: {metadata.get('product_category', 'N/A')}")
                else:
                    print("\nNo results found.")
            
            except KeyboardInterrupt:
                self.log("\nExiting interactive mode...")
                break
            except Exception as e:
                self.log(f"Error: {e}", "ERROR")
