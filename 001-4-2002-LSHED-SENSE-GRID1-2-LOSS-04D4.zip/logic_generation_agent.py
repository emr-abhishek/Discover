import os
import json
import requests
import re
import random
import string
from pathlib import Path
from agents.base_agent import BaseAgent, QueryRequest
from env import UPLOAD_DIR, OLLAMA_URL
from logging_utils.logger import Logger

logger = Logger.get_logger(name="LogicGenerationAgent")

class ControlSheetAssembler:
    """Template-driven engine for generating Native Control Logic SVGs"""
    def __init__(self, frame_template_path):
        self.frame_template_path = frame_template_path
        
        # Core Library of Parameterized Ovation Components
        self.templates = {
            "INPUT": """
            <g cb-classname="ExternalPointInterface" cb-algorithm-id="{alg_id}" cb-alg-oVp3="NO" cb-function-name="INPUT" cb-alg-[RAND_ID]="{name}" id="[RAND_ID]">
                <ellipse cb-classname="GraphicEllipseEntity" cy="{y}" id="[RAND_ID]" class="algorithm" cx="{x}" ry="40" rx="40"/>
                <rect cb-classname="GraphicRectangleEntity" height="80" id="[RAND_ID]" width="30" y="{y_minus_40}" class="algorithm" x="{x_minus_70}"/>
                <line cb-classname="GraphicLineEntity" y1="{y}" id="[RAND_ID]" x1="{x_minus_70}" class="algorithm" x2="{x_minus_40}" y2="{y}"/>
                
                <g cb-classname="PointStatusIndicator" visibility="hidden" id="[RAND_ID]" cb-source="[RAND_STR]" cb-indicator-type="Highway">
                    <line cb-classname="GraphicLineEntity" x2="{x}" id="[RAND_ID]" y2="{y_minus_40}" x1="{x_minus_40}" class="algorithmline" y1="{y}"/>
                    <line cb-classname="GraphicLineEntity" class="algorithmline" y2="{y}" id="[RAND_ID]" x2="{x_plus_40}" x1="{x}" y1="{y_minus_40}"/>
                    <line cb-classname="GraphicLineEntity" class="algorithmline" id="[RAND_ID]" y1="{y}" y2="{y_plus_40}" x1="{x_plus_40}" x2="{x}"/>
                    <line cb-classname="GraphicLineEntity" class="algorithmline" x2="{x_minus_40}" y2="{y}" y1="{y_plus_40}" id="[RAND_ID]" x1="{x}"/>
                </g>
                
                <g cb-classname="PointStatusIndicator" visibility="hidden" id="[RAND_ID]" cb-source="[RAND_STR]" cb-indicator-type="hardware">
                    <line cb-classname="GraphicLineEntity" y2="{y_minus_40}" class="algorithmline" y1="{y_minus_40}" id="[RAND_ID]" x1="{x_minus_40}" x2="{x_plus_40}"/>
                    <line cb-classname="GraphicLineEntity" x2="{x_plus_40}" class="algorithmline" y2="{y_plus_40}" x1="{x_plus_40}" y1="{y_minus_40}" id="[RAND_ID]"/>
                    <line cb-classname="GraphicLineEntity" id="[RAND_ID]" y1="{y_plus_40}" x2="{x_minus_40}" x1="{x_plus_40}" y2="{y_plus_40}" class="algorithmline"/>
                </g>
                
                <g cb-classname="PointStatusIndicator" visibility="visible" cb-indicator-type="alarm" cb-source="[RAND_STR]" id="[RAND_ID]">
                    <text cb-classname="GraphicTextEntity" fill="#000000" class="algorithm" id="[RAND_ID]" font-family="arial" font-size="20" y="{y_minus_11}" x="{x_minus_63}"> A </text>
                </g>
                
                <g cb-classname="PointStatusIndicator" id="[RAND_ID]" cb-indicator-type="ingraphic" visibility="hidden" cb-source="[RAND_STR]">
                    <text cb-classname="GraphicTextEntity" fill="#000000" y="{y_plus_29}" font-size="20" font-family="Arial" id="[RAND_ID]" x="{x_minus_65}" class="algorithm"> G </text>
                </g>
                
                <g cb-classname="PointDescription" id="[RAND_ID]" text-anchor="end" cb-content="extended" class="algorithm" baseline-shift="-50%" cb-anchor-x="{x_minus_88}" cb-anchor-y="{y_minus_6}" cb-max-width="350" cb-source="[RAND_STR]" cb-labeled="false">
                    <text cb-classname="GraphicTextEntity" text-anchor="end" baseline-shift="-50%" class="algorithm" y="{y_minus_23}" x="{x_minus_88}" id="[RAND_ID]">{name}</text>
                    <text cb-classname="GraphicTextEntity" y="{y_plus_13}" id="[RAND_ID]" class="algorithm" baseline-shift="-50%" text-anchor="end" x="{x_minus_88}">STATUS</text>
                </g>
                
                <g cb-classname="DynamicText" cb-labeled="false" text-anchor="start" cb-source="[RAND_STR]" id="[RAND_ID]" cb-pin-name="[RAND_STR]" class="algorithm">
                    <text cb-classname="GraphicTextEntity" baseline-shift="0%" fill="black" id="[RAND_ID]" text-anchor="start" font-family="Arial" x="{x_plus_60}" text-decoration="normal" font-style="normal" class="algorithm" font-size="20" font-weight="normal" y="{y_minus_20}"/>
                </g>
                
                <g cb-classname="PointReferences" cb-anchor-x="{x_plus_60}" cb-anchor-y="{y_plus_10}" cb-originator="true" cb-source="[RAND_STR]" baseline-shift="-100%" cb-max-width="230" class="signal" id="[RAND_ID]" text-anchor="start">
                    <text cb-classname="GraphicTextEntity" class="algorithm" id="[RAND_ID]" baseline-shift="-100%" text-anchor="start" y="{y_plus_10}" x="{x_plus_60}">1/5680</text>
                </g>
                
                <g cb-classname="ControlPin" id="{pin_OUT}" cb-pin-name="[RAND_STR]">
                    <line cb-classname="GraphicLineEntity" x1="{x_plus_40}" id="[RAND_ID]" y1="{y}" x2="{x_plus_60}" y2="{y}" class="signalline"/>
                    {segments}
                </g>
            </g>""",
            
            "OUTPUT": """
            <g cb-classname="ExternalPointInterface" cb-algorithm-id="{alg_id}" cb-function-name="OUTPUT" id="[RAND_ID]" cb-alg-[RAND_ID]="[RAND_STR]">
                <ellipse cb-classname="GraphicEllipseEntity" id="[RAND_ID]" cy="{y}" rx="40" ry="40" cx="{x}" class="algorithm"/>
                <rect cb-classname="GraphicRectangleEntity" width="30" x="{x_plus_40}" height="80" y="{y_minus_40}" class="algorithm" id="[RAND_ID]"/>
                <line cb-classname="GraphicLineEntity" class="algorithm" y2="{y}" id="[RAND_ID]" x2="{x_plus_70}" x1="{x_plus_40}" y1="{y}"/>
                
                <g cb-classname="PointStatusIndicator" id="[RAND_ID]" visibility="hidden" cb-indicator-type="highway" cb-source="[RAND_STR]">
                    <line cb-classname="GraphicLineEntity" id="[RAND_ID]" class="algorithmline" x1="{x_minus_40}" x2="{x}" y2="{y_minus_40}" y1="{y}"/>
                    <line cb-classname="GraphicLineEntity" x1="{x}" y1="{y_minus_40}" class="algorithmline" y2="{y}" id="[RAND_ID]" x2="{x_plus_40}"/>
                    <line cb-classname="GraphicLineEntity" x2="{x}" x1="{x_plus_40}" id="[RAND_ID]" y2="{y_plus_40}" class="algorithmline" y1="{y}"/>
                    <line cb-classname="GraphicLineEntity" x1="{x}" y1="{y_plus_40}" y2="{y}" class="algorithmline" x2="{x_minus_40}" id="[RAND_ID]"/>
                </g>
                
                <g cb-classname="PointStatusIndicator" visibility="hidden" id="[RAND_ID]" cb-indicator-type="hardware" cb-source="[RAND_STR]">
                    <line cb-classname="GraphicLineEntity" x1="{x_plus_40}" x2="{x_minus_40}" y1="{y_minus_40}" id="[RAND_ID]" class="algorithmline" y2="{y_minus_40}"/>
                    <line cb-classname="GraphicLineEntity" x1="{x_minus_40}" id="[RAND_ID]" x2="{x_minus_40}" class="algorithmline" y2="{y_plus_40}" y1="{y_minus_40}"/>
                    <line cb-classname="GraphicLineEntity" class="algorithmline" x2="{x_plus_40}" x1="{x_minus_40}" y1="{y_plus_40}" y2="{y_plus_40}" id="[RAND_ID]"/>
                </g>
                
                <g cb-classname="PointStatusIndicator" id="[RAND_ID]" cb-indicator-type="alarm" visibility="visible" cb-source="[RAND_STR]">
                    <text cb-classname="GraphicTextEntity" font-family="Arial" x="{x_plus_47}" y="{y_minus_11}" font-size="20" class="algorithm" fill="#000000" id="[RAND_ID]"> A </text>
                </g>
                
                <g cb-classname="PointStatusIndicator" visibility="visible" id="[RAND_ID]" cb-indicator-type="ingraphic" cb-source="[RAND_STR]">
                    <text cb-classname="GraphicTextEntity" x="{x_plus_45}" font-family="Arial" font-size="20" y="{y_plus_30}" id="[RAND_ID]" class="algorithm" fill="#000000"> G </text>
                </g>
                
                <g cb-classname="DynamicText" cb-pin-name="[RAND_STR]" id="[RAND_ID]" text-anchor="end" class="algorithm" cb-labeled="false" cb-source="[RAND_STR]">
                    <text cb-classname="GraphicTextEntity" y="{y_minus_21}" font-size="20" font-family="Arial" fill="black" text-decoration="normal" x="{x_minus_63}" text-anchor="end" id="[RAND_ID]" font-style="normal" baseline-shift="0%" class="algorithm" font-weight="normal"/>
                </g>
                
                <g cb-classname="PointReferences" cb-anchor-x="{x_minus_62}" cb-originator="false" cb-max-width="240" baseline-shift="-100%" text-anchor="end" id="[RAND_ID]" cb-anchor-y="{y_plus_16}" class="signal" cb-source="[RAND_STR]">
                    <text cb-classname="GraphicTextEntity" class="algorithm" text-anchor="end" id="[RAND_ID]" x="{x_minus_62}" baseline-shift="-100%" y="{y_plus_16}"> 1/7100 </text>
                </g>
                
                <g cb-classname="PointDescription" baseline-shift="-50%" text-anchor="start" cb-anchor-y="{y_minus_2}" cb-labeled="false" cb-content="extended" class="algorithm" cb-anchor-x="{x_plus_91}" cb-max-width="350" id="[RAND_ID]" cb-source="[RAND_STR]">
                    <text cb-classname="GraphicTextEntity" id="[RAND_ID]" x="{x_plus_91}" y="{y_minus_19}" class="algorithm" baseline-shift="-50%" text-anchor="start">{name}</text>
                    <text cb-classname="GraphicTextEntity" x="{x_plus_91}" y="{y_plus_17}" text-anchor="start" id="[RAND_ID]" baseline-shift="-50%" class="algorithm">CMD</text>
                </g>
                
                <g cb-classname="ControlPin" cb-pin-name="[RAND_STR]" id="{pin_IN}">
                    <line cb-classname="GraphicLineEntity" y1="{y}" class="signalline" y2="{y}" x1="{x_minus_60}" id="[RAND_ID]" x2="{x_minus_40}"/>
                    <polygon cb-classname="GraphicPolygonEntity" points="{x_minus_40},{y} {x_minus_51},{y_minus_6} {x_minus_51},{y_plus_5}" class="signal" id="[RAND_ID]"/>
                </g>
            </g>""",

            "AND": """
            <g cb-classname="FastBooleanAlgorithm" cb-function-name="AND" id="[RAND_ID]" cb-algorithm-id="{alg_id}" cb-modify-id="00000007" cb-alg-[RAND_ID]="[RAND_STR]">
                <rect cb-classname="GraphicRectangleEntity" width="80" x="{x}" class="algorithm" height="60" y="{y_minus_30}" id="[RAND_ID]"/>
                <text cb-classname="GraphicTextEntity" baseline-shift="-50%" x="{x_plus_40}" text-anchor="middle" id="[RAND_ID]" class="algorithm" y="{y}"> AND </text>
                <line cb-classname="GraphicLineEntity" id="[RAND_ID]" class="algorithmline" x1="{x}" x2="{x}" y1="{y_minus_60}" y2="{y_plus_100}"/>
                
                <g cb-classname="ControlPin" id="{pin_IN1}" cb-pin-name="[RAND_STR]">
                    <line cb-classname="GraphicLineEntity" y1="{y_minus_40}" id="[RAND_ID]" x2="{x}" y2="{y_minus_40}" x1="{x_minus_20}" class="signalline"/>
                    <polygon cb-classname="GraphicPolygonEntity" points="{x},{y_minus_40} {x_minus_11},{y_minus_44} {x_minus_11},{y_minus_36}" class="signal" id="[RAND_ID]"/>
                    <g cb-classname="DynamicText" class="signal" id="[RAND_ID]" text-anchor="end" cb-source="[RAND_STR]">
                        <text cb-classname="GraphicTextEntity" class="signal" font-weight="normal" id="[RAND_ID]" y="{y_minus_44}" font-style="normal" text-anchor="end" baseline-shift="5%" x="{x_minus_11}" fill="black" text-decoration="normal"/>
                    </g>
                </g>
                <g cb-classname="ControlPin" cb-pin-name="[RAND_STR]" id="{pin_IN2}">
                    <line cb-classname="GraphicLineEntity" id="[RAND_ID]" y1="{y_minus_20}" x1="{x_minus_20}" class="signalline" y2="{y_minus_20}" x2="{x}"/>
                    <polygon cb-classname="GraphicPolygonEntity" points="{x},{y_minus_20} {x_minus_11},{y_minus_24} {x_minus_11},{y_minus_16}" class="signal" id="[RAND_ID]"/>
                    <g cb-classname="DynamicText" class="signal" text-anchor="end" id="[RAND_ID]" cb-source="[RAND_STR]">
                        <text cb-classname="GraphicTextEntity" font-weight="normal" text-decoration="normal" text-anchor="end" id="[RAND_ID]" x="{x_minus_11}" font-style="normal" baseline-shift="5%" class="signal" y="{y_minus_24}" fill="black"/>
                    </g>
                </g>
                <g cb-classname="ControlPin" id="{pin_IN3}" cb-pin-name="[RAND_STR]">
                    <line cb-classname="GraphicLineEntity" class="signalline" y2="{y}" x1="{x_minus_20}" id="[RAND_ID]" y1="{y}" x2="{x}"/>
                    <polygon cb-classname="GraphicPolygonEntity" class="signal" points="{x},{y} {x_minus_11},{y_minus_4} {x_minus_11},{y_plus_4}" id="[RAND_ID]"/>
                    <g cb-classname="DynamicText" text-anchor="end" class="signal" id="[RAND_ID]" cb-source="[RAND_STR]">
                        <text cb-classname="GraphicTextEntity" fill="black" text-anchor="end" y="{y_minus_4}" x="{x_minus_11}" id="[RAND_ID]" font-style="normal" font-weight="normal" text-decoration="normal" baseline-shift="5%" class="signal"/>
                    </g>
                </g>
                <g cb-classname="ControlPin" cb-pin-name="[RAND_STR]" id="{pin_IN4}">
                    <line cb-classname="GraphicLineEntity" y1="{y_plus_20}" class="signalline" x1="{x_minus_20}" x2="{x}" y2="{y_plus_20}" id="[RAND_ID]"/>
                    <polygon cb-classname="GraphicPolygonEntity" class="signal" points="{x},{y_plus_20} {x_minus_11},{y_plus_16} {x_minus_11},{y_plus_24}" id="[RAND_ID]"/>
                    <g cb-classname="DynamicText" class="signal" id="[RAND_ID]" text-anchor="end" cb-source="[RAND_STR]">
                        <text cb-classname="GraphicTextEntity" class="signal" x="{x_minus_11}" text-decoration="normal" font-weight="normal" id="[RAND_ID]" baseline-shift="5%" y="{y_plus_24}" font-style="normal" fill="black" text-anchor="end"/>
                    </g>
                </g>
            </g>"""
        }

    def _rand_id(self, length=4):
        """Generates a 4-character Ovation-compliant Element ID (e.g., 3Kaz)"""
        chars = string.ascii_letters + string.digits
        return ''.join(random.choices(chars, k=length))

    def _rand_str(self):
        """Generates a 10-character Ovation Hash for cb-source (e.g., Cw-NjL-kRF)"""
        chars = string.ascii_letters + string.digits
        p1 = ''.join(random.choices(chars, k=2))
        p2 = ''.join(random.choices(chars, k=3))
        p3 = ''.join(random.choices(chars, k=3))
        return f"{p1}-{p2}-{p3}"

    def _inject_randoms(self, template_str):
        """Finds and replaces placeholders with unique random values one by one"""
        while "[RAND_ID]" in template_str:
            template_str = template_str.replace("[RAND_ID]", self._rand_id(), 1)
        while "[RAND_STR]" in template_str:
            template_str = template_str.replace("[RAND_STR]", self._rand_str(), 1)
        return template_str

    def _generate_coordinate_kwargs(self, base_x, base_y):
        """Generates dynamic offset parameters to perfectly align template graphics."""
        kwargs = {'x': base_x, 'y': base_y}
        # Math offsets mapped directly from the Ovation standard blocks
        offsets = [
            1, 2, 3, 4, 5, 6, 8, 10, 11, 13, 14, 15, 16, 17, 19, 20, 21, 23, 24, 
            27, 29, 30, 35, 36, 37, 40, 44, 45, 47, 51, 56, 57, 60, 61, 62, 63, 
            64, 65, 70, 76, 80, 84, 88, 91, 95, 100
        ]
        for offset in offsets:
            kwargs[f'x_plus_{offset}'] = base_x + offset
            kwargs[f'x_minus_{offset}'] = base_x - offset
            kwargs[f'y_plus_{offset}'] = base_y + offset
            kwargs[f'y_minus_{offset}'] = base_y - offset
        return kwargs

    def _extract_frame_parts(self, frame_content):
        """Isolates the <style> block and the actual visual <g> graphics from the master template."""
        style_match = re.search(r'(<style.*?</style>)', frame_content, re.DOTALL | re.IGNORECASE)
        style_block = style_match.group(1) if style_match else ""
        
        svg_body_match = re.search(r'<svg[^>]*>(.*?)</svg>', frame_content, re.DOTALL | re.IGNORECASE)
        raw_frame_graphics = ""
        if svg_body_match:
            raw_frame_graphics = svg_body_match.group(1).replace(style_block, '').strip()
            
        return style_block, raw_frame_graphics
    
    def assemble(self, blueprint, output_filename):
        # 1. Load Master Frame
        try:
            with open(self.frame_template_path, 'r', encoding='utf-8-sig') as f:
                frame_content = f.read()
        except UnicodeDecodeError:
            with open(self.frame_template_path, 'r', encoding='utf-16') as f:
                frame_content = f.read()

        _, raw_frame_graphics = self._extract_frame_parts(frame_content)

        # 2. Assign Grid Locations
        comp_data = {}
        y_positions = {"INPUT": 960, "LOGIC": 1050, "OUTPUT": 1080}
        x_positions = {"INPUT": 560, "LOGIC": 1440, "OUTPUT": 4840}

        # --- FIX 1: Generate Strict 4-Char IDs and Pin Dictionaries ---
        for i, comp in enumerate(blueprint.get("components", [])):
            old_cid = comp.get("id")
            cid = f"C{i+1:03X}"      # E.g. C001
            alg_id = f"{i+1:03X}"    # E.g. 001
            
            ctype = comp.get("type", "LOGIC").upper()
            func = comp.get("function", "UNKNOWN").upper() if ctype == "LOGIC" else ctype
            
            x = x_positions.get(ctype, 1440)
            y = y_positions.get(ctype, 1000)
            
            # Create exact 4-character Pin IDs for Cross-Referencing
            pin_ids = {
                "OUT": f"P{alg_id}O",
                "IN":  f"P{alg_id}I",
                "IN1": f"P{alg_id}1",
                "IN2": f"P{alg_id}2",
                "IN3": f"P{alg_id}3",
                "IN4": f"P{alg_id}4",
                "IN5": f"P{alg_id}5",
                "IN6": f"P{alg_id}6",
                "IN7": f"P{alg_id}7",
                "IN8": f"P{alg_id}8"
            }

            pins = {"out_x": x, "out_y": y, "in_x": x, "in_y": y}
            if ctype == "INPUT":
                pins["out_x"], pins["out_y"] = x + 60, y
            elif ctype == "OUTPUT":
                pins["in_x"], pins["in_y"] = x - 60, y
            elif func == "FLIPFLOP":
                pins["in_x"], pins["in_y"] = x - 20, y + 20
                pins["out_x"], pins["out_y"] = x + 100, y + 20
            elif func in ["NOT", "ONESHOT"]:
                pins["in_x"], pins["in_y"] = x - 20, y
                pins["out_x"], pins["out_y"] = x + 60, y
            else: # AND, OR
                pins["in_x"], pins["in_y"] = x - 20, y - 40 # Default IN1
                pins["out_x"], pins["out_y"] = x + 100, y   # Fixed OUT offset for 8-input block

            comp_data[old_cid] = {
                "id": cid, "alg_id": alg_id, "pin_ids": pin_ids, "type": ctype, 
                "func": func, "name": comp.get("name", cid),
                "x": x, "y": y, "pins": pins, "segments_xml": ""
            }
            y_positions[ctype] += 250 

        # 3. Build Interconnecting SignalSegments with Dynamic Y-Routing
        conn_idx = 1
        target_pin_counters = {} 
        
        for conn in blueprint.get("connections", []):
            src_id, tgt_id = conn.get("from"), conn.get("to")
            tgt_pin = conn.get("to_pin", "").upper()
            
            if src_id in comp_data and tgt_id in comp_data:
                tgt_func = comp_data[tgt_id]["func"]
                x1, y1 = comp_data[src_id]["pins"]["out_x"], comp_data[src_id]["pins"]["out_y"]
                x2, y2 = comp_data[tgt_id]["pins"]["in_x"], comp_data[tgt_id]["pins"]["in_y"]

                # Auto-route cascading inputs for AND / OR gates
                if tgt_func in ["AND", "OR"]:
                    if not tgt_pin or tgt_pin == "IN":
                        count = target_pin_counters.get(tgt_id, 1)
                        tgt_pin = f"IN{count}"
                        target_pin_counters[tgt_id] = count + 1
                    
                    try:
                        pin_num = int(tgt_pin.replace("IN", ""))
                        offsets = [-80, -60, -40, -20, 20, 40, 60, 80]
                        y_offset = offsets[pin_num - 1] if pin_num <= 8 else 0
                        y2 = comp_data[tgt_id]["y"] + y_offset
                    except ValueError:
                        pass
                elif not tgt_pin:
                    tgt_pin = "IN"

                # Route to FLIPFLOP specific pins
                if tgt_func == "FLIPFLOP" and tgt_pin == "R":
                    y2 = comp_data[tgt_id]["y"] + 60

                # --- FIX 2: Bind the Exact Target Pin ID for the compiler ---
                tgt_pin_id = comp_data[tgt_id]["pin_ids"].get(tgt_pin, f"P{comp_data[tgt_id]['alg_id']}I")
                
                line_id = self._rand_id()
                conn_str = f"{conn_idx:03X}"

                # Link using explicit IDs
                segment = f"""
                <g cb-classname="SignalSegment" id="S{conn_str}">
                    <line cb-classname="GraphicLineEntity" x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#1e12bf" stroke-dasharray="5,4" class="signalline" id="{line_id}"/>
                    <g cb-classname="SignalConnection" cb-input-pin="${tgt_pin_id}$" cb-graphic-line="${line_id}$" id="{self._rand_id()}"/>
                </g>"""
                comp_data[src_id]["segments_xml"] += segment
                conn_idx += 1

        # 4. Populate logic templates
        generated_logic_blocks = ""
        for cid, data in comp_data.items():
            template_key = data["func"] if data["type"] == "LOGIC" else data["type"]
            template_str = self.templates.get(template_key)
            if template_str:
                format_kwargs = self._generate_coordinate_kwargs(data['x'], data['y'])
                
                # --- FIX 3: Inject pin_ids directly into format_kwargs ---
                format_kwargs.update({
                    "id": data["id"], "alg_id": data["alg_id"], "name": data["name"], 
                    "segments": data["segments_xml"], **{f"pin_{k}": v for k, v in data["pin_ids"].items()}
                })
                
                # 1. Format Python variables (x, y, segments, pin_IN1, etc)
                rendered_block = template_str.format(**format_kwargs)
                
                # 2. Replace [RAND_ID] and [RAND_STR] placeholders with live hashes
                rendered_block = self._inject_randoms(rendered_block)
                
                generated_logic_blocks += rendered_block + "\n"

        # 5. Final Assembly (Strict ControlFunction Hierarchy & Native CSS)
        sheet_title = blueprint.get("sheet_name", "GENERATED_SHEET").upper()
        
        final_svg = f"""<?xml version="1.0" encoding="UTF-8" ?>
<svg cb-classname="ControlFunction" cb-sheet-number="2002" cb-key="511234244332" cb-revision-time="04/26/2021" height="3750" cb-sheet-title="{sheet_title}" cb-task-id="4" cb-doc-hash="4E25AD1856CDCD1EDD66D940F5415A98607357238CCFC4AD61F3FB9A2D65471C" cb-reviewer="Vedabit Nag" cb-path="Z:/MEDAN/NET0/UNIT1/CONTROLFUNCTIONS" id="1" cb-ortho-mode="enabled" cb-component="LSHED" cb-revision="0" cb-engineer="Soumik Batul" cb-auto-time="03/23/2021 08:52:41" width="5575" cb-create-time="07/20/2015" cb-modify-id="00000007" cb-drop-id="1" cb-function-id="04D4" cb-modified-timestamp="1617716365" cb-snap-grid="10">

<style cb-classname="EntityStyle" type="text/css" id="2"> .algorithm {{ fill: white; stroke: black; stroke-width: 3 }} .algorithm-function {{ fill: black; stroke: none }} .algorithm-functionline {{ fill: none; stroke: black; stroke-linecap: round; stroke-width: 3 }} .algorithm-name {{ fill: black; stroke: none }} .algorithm-nameline {{ fill: none; stroke: black; stroke-linecap: round; stroke-width: 3 }} .algorithm-sequence {{ fill: black; stroke: none; visibility: hidden }} .algorithm-sequenceline {{ fill: none; stroke: black; stroke-linecap: round; stroke-width: 3; visibility: hidden }} .algorithmline {{ fill: none; stroke: black; stroke-linecap: round; stroke-width: 3 }} .annotation {{ fill: black; stroke: none }} .annotationline {{ fill: none; stroke: black; stroke-linecap: round; stroke-width: 3 }} .frame {{ fill: black; stroke: none }} .frameline {{ fill: none; stroke: black; stroke-linecap: round; stroke-width: 3 }} .signal {{ fill: black; stroke: none }} .signalline {{ fill: none; stroke: black; stroke-linecap: round; stroke-width: 3 }} text.algorithm {{ fill: black; font-family: Arial; font-size: 22; stroke: none }} text.algorithm-function {{ fill: black; font-family: Arial; font-size: 22; stroke: none }} text.algorithm-name {{ fill: black; font-family: Arial; font-size: 22; stroke: none }} text.algorithm-sequence {{ fill: black; font-family: Arial; font-size: 22; stroke: none; visibility: hidden }} text.annotation {{ fill: black; font-family: Arial; font-size: 22; stroke: none }} text.frame {{ fill: black; font-family: Arial; font-size: 18; stroke: none }} text.signal {{ fill: black; font-family: Arial; font-size: 12; stroke: none }} </style>

<g cb-classname="NamedObject" id="3" cb-objectname="Comments">
<text cb-classname="GraphicTextEntity" baseline-shift="0%" y="980" id="3Kl9" font-size="22" fill="#000000" x="1830" font-family="MS Shell Dlg 2" class="annotation"> Open </text>
<text cb-classname="GraphicTextEntity" y="1460" font-family="MS Shell Dlg 2" id="3Ka1" class="annotation" baseline-shift="0%" x="1830" font-size="22" fill="#000000"> Open </text>
</g>

<g cb-classname="AlgorithmContainer" cb-objectname="Algorithms" id="4">
{generated_logic_blocks}
</g>

<g cb-classname="IncludeDocument" id="5" cb-objectname="frame">
{raw_frame_graphics}
</g>

</svg>""".lstrip()

        # 6. Save to disk (Must be utf-8 to match the XML header)
        save_dir = Path(UPLOAD_DIR) / "logic_diagrams" / "generated"
        save_dir.mkdir(parents=True, exist_ok=True)
        save_path = save_dir / output_filename
        
        with open(save_path, 'w', encoding='utf-8') as f:
            f.write(final_svg)
            
        return str(save_path)


class LogicGenerationAgent(BaseAgent):
    def __init__(self):
        self.name = "LogicGenerationAgent"
        self.agent_name = "LogicGenerationAgent"
        self.agent_description = "Specialized agent for designing and generating new control logic sheets (SVG) from natural language requirements."
        self.model = "llama3.1:70b" 
        
        self.template_path = Path(UPLOAD_DIR) / "logic_diagrams" / "templates" / "Frame.svg"

    def run(self, query: QueryRequest):
        logger.info(f"LogicGenerationAgent running for: {query.question}")
        
        if not self.template_path.exists():
            return {"answer": f"Template missing. Please ensure 'Frame.svg' is uploaded to {self.template_path}."}

        # 1. Enforce strict JSON output from the LLM
        prompt = f"""
        You are a Senior Lead Control Systems Engineer. 
        Convert the following logic requirement into a strict JSON blueprint.
        
        **REQUIREMENT:**
        "{query.question}"
        
        **RULES:**
        - ONLY use these functions: INPUT, OUTPUT, AND, OR, NOT, ONESHOT, FLIPFLOP, ONDELAY, OFFDELAY.
        - The response MUST be pure JSON. Do not include markdown formatting (like ```json), conversational text, or explanations.
        
        **REQUIRED JSON SCHEMA:**
        {{
            "sheet_name": "New_Logic_Sheet",
            "components": [
                {{"id": "IN1", "type": "INPUT", "name": "START_PB"}},
                {{"id": "G1", "type": "LOGIC", "function": "AND", "name": "Start Permissive"}},
                {{"id": "OUT1", "type": "OUTPUT", "name": "MOTOR_CMD"}}
            ],
            "connections": [
                {{"from": "IN1", "to": "G1"}},
                {{"from": "G1", "to": "OUT1"}}
            ]
        }}
        """

        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.0, "num_predict": 2000} # Max determinism for code generation
        }

        try:
            # Step 1: Request AI JSON Blueprint
            response = requests.post(f"{OLLAMA_URL}/api/generate", json=payload, timeout=300)
            if response.status_code != 200:
                return {"answer": f"Error generating blueprint. Status: {response.status_code}"}
                
            raw_text = response.json().get("response", "").strip()
            
            # Clean up potential markdown blocks if the LLM disobeys instructions
            raw_text = raw_text.replace("```json", "").replace("```", "").strip()
            
            blueprint = json.loads(raw_text)
            
            # Step 2: Build the SVG using the new Assembler
            sheet_name = blueprint.get("sheet_name", "Generated_Logic")
            filename = f"{sheet_name}.svg"
            
            assembler = ControlSheetAssembler(self.template_path)
            saved_path = assembler.assemble(blueprint, filename)
            
            return {
                "answer": f"Successfully designed logic sheet: **{sheet_name}**.\n\n**Components Used:** {len(blueprint.get('components', []))}\n**Connections Made:** {len(blueprint.get('connections', []))}\n\nThe new logic sheet has been generated and saved based on your requirements.",
                "references": [{
                    "filename": filename,
                    "description": "Generated Logic Sheet",
                    "pages": [1],
                    "link": f"/files/logic_diagrams/generated/{filename}"
                }],
                "confidence": "HIGH",
                "related_queries": [f"Explain the generated {sheet_name} logic", "Modify the design requirement"]
            }
            
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse AI JSON: {raw_text}")
            return {"answer": "The AI failed to generate a valid JSON structure for the logic drawing. Please simplify your design request."}
        except Exception as e:
            logger.error(f"Logic Generation Error: {str(e)}")
            return {"answer": f"An error occurred during logic generation: {str(e)}"}